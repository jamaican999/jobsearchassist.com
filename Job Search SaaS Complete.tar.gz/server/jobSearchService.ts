import { distance } from 'fuzzball';
// @ts-ignore - pdf-parse-fork doesn't have type definitions
import pdfParse from 'pdf-parse-fork';
import type OpenAI from 'openai';

// Lazy initialization with dynamic import to completely defer OpenAI loading
let _openai: OpenAI | null = null;

async function getOpenAI(): Promise<OpenAI> {
  if (!_openai) {
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      throw new Error('OPENAI_API_KEY environment variable is not set');
    }
    // Dynamic import to defer loading until runtime
    const { default: OpenAIClient } = await import('openai');
    _openai = new OpenAIClient({ apiKey });
  }
  return _openai;
}

export interface JobSearchParams {
  searchKeywords: string[];
  filterKeywords: string[];
  location?: string;
  datePosted?: 'today' | '3days' | 'week' | 'month';
  minKeywordMatches?: number;
  fuzzyThreshold?: number;
  maxResults?: number;
  tier?: 'expert' | 'pro' | 'superhero';
  companySearch?: boolean;
  companyName?: string;
}

export interface Job {
  jobId: string;
  title: string;
  company: string;
  location: string;
  description: string;
  workStyle: 'Remote' | 'Hybrid' | 'In-Office';
  postingDate: string;
  jobUrl: string;
  keywordMatches: string[];
  matchCount: number;
}

export interface SearchResults {
  jobs: Job[];
  totalFound: number;
  totalFiltered: number;
}

/**
 * Extract work style from job data
 */
function extractWorkStyle(job: any): 'Remote' | 'Hybrid' | 'In-Office' {
  const extensions = JSON.stringify(job.detected_extensions || {}).toLowerCase();
  const description = (job.description || '').toLowerCase();
  const title = (job.title || '').toLowerCase();
  const location = (job.location || '').toLowerCase();
  
  const combinedText = `${extensions} ${description} ${title} ${location}`;
  
  const remoteKeywords = ['remote', 'work from home', '100% remote', 'fully remote', 'wfh', 'anywhere', 'work remotely'];
  if (remoteKeywords.some(kw => combinedText.includes(kw))) {
    return 'Remote';
  }
  
  const hybridKeywords = ['hybrid', 'flexible work', 'flexible location', 'mix of remote', 'partially remote'];
  if (hybridKeywords.some(kw => combinedText.includes(kw))) {
    return 'Hybrid';
  }
  
  return 'In-Office';
}

/**
 * Extract posting date from job data
 */
function extractPostingDate(job: any): string {
  const extensions = job.detected_extensions || {};
  
  if (extensions.posted_at) {
    return extensions.posted_at;
  }
  
  if (extensions.schedule_type && typeof extensions.schedule_type === 'string') {
    const schedule = extensions.schedule_type.toLowerCase();
    if (['ago', 'today', 'yesterday'].some(word => schedule.includes(word))) {
      return extensions.schedule_type;
    }
  }
  
  const highlights = job.job_highlights || [];
  for (const highlight of highlights) {
    if (highlight.items) {
      for (const item of highlight.items) {
        if (typeof item === 'string' && ['posted', 'ago', 'today'].some(word => item.toLowerCase().includes(word))) {
          return item;
        }
      }
    }
  }
  
  return 'Unknown';
}

/**
 * Extract job URL from job data
 */
function extractJobUrl(job: any): string {
  // Priority 1: apply_options
  if (job.apply_options && Array.isArray(job.apply_options) && job.apply_options.length > 0) {
    const link = job.apply_options[0]?.link;
    if (link && link.trim()) return link.trim();
  }
  
  // Priority 2: apply_link
  if (job.apply_link && job.apply_link.trim()) {
    return job.apply_link.trim();
  }
  
  // Priority 3: share_url
  if (job.share_url && job.share_url.trim()) {
    return job.share_url.trim();
  }
  
  // Priority 4: related_links
  if (job.related_links && Array.isArray(job.related_links) && job.related_links.length > 0) {
    const link = job.related_links[0]?.link;
    if (link && link.trim()) return link.trim();
  }
  
  // Priority 5: Construct from job_id
  if (job.job_id) {
    return `https://www.google.com/search?ibp=htl;jobs&q=${job.job_id}`;
  }
  
  return 'N/A';
}

/**
 * Fuzzy match two strings
 */
function fuzzyMatch(text1: string, text2: string, threshold: number = 75): boolean {
  return distance(text1.toLowerCase(), text2.toLowerCase()) >= threshold;
}

/**
 * Count keyword matches in job description using fuzzy matching
 */
function countKeywordMatches(
  description: string,
  keywords: string[],
  fuzzyThreshold: number = 75
): { matchedKeywords: string[]; matchCount: number } {
  const descLower = description.toLowerCase();
  const matched: string[] = [];
  
  for (const keyword of keywords) {
    const kwLower = keyword.toLowerCase();
    
    // Exact match
    if (descLower.includes(kwLower)) {
      matched.push(keyword);
      continue;
    }
    
    // Fuzzy match
    const words = descLower.split(/\s+/);
    const kwWordCount = kwLower.split(/\s+/).length;
    
    let found = false;
    for (let i = 0; i <= words.length - kwWordCount; i++) {
      const phrase = words.slice(i, i + Math.min(5, kwWordCount + 2)).join(' ');
      if (fuzzyMatch(phrase, kwLower, fuzzyThreshold)) {
        matched.push(keyword);
        found = true;
        break;
      }
    }
    
    if (found) continue;
  }
  
  const uniqueMatched = Array.from(new Set(matched));
  return {
    matchedKeywords: uniqueMatched,
    matchCount: uniqueMatched.length,
  };
}

/**
 * Search jobs using a single query with Serper.dev
 */
async function searchSingleQuery(
  query: string,
  location?: string,
  datePosted?: string,
  companyName?: string
): Promise<any[]> {
  const apiKey = process.env.SERPER_API_KEY;
  
  if (!apiKey) {
    console.error('[Serper] API key not found');
    return [];
  }
  
  // Build search query
  let searchQuery = query;
  if (companyName) {
    searchQuery += ` at ${companyName}`;
  }
  
  // Build request body
  const requestBody: any = {
    q: searchQuery,
    location: location || 'United States',
    gl: 'us',
    hl: 'en',
    num: 100, // Request max results from Serper
  };
  
  // Add date filter if specified
  if (datePosted) {
    const dateFilters: Record<string, string> = {
      today: 'qdr:d',
      '3days': 'qdr:d3',
      week: 'qdr:w',
      month: 'qdr:m',
    };
    requestBody.tbs = dateFilters[datePosted] || 'qdr:w';
  }
  
  try {
    const response = await fetch('https://google.serper.dev/jobs', {
      method: 'POST',
      headers: {
        'X-API-KEY': apiKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestBody),
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error(`[Serper] API error: ${response.status} - ${errorText}`);
      return [];
    }
    
    const data = await response.json();
    return data.jobs_results || [];
  } catch (error) {
    console.error('[Serper] Search error:', error);
    return [];
  }
}

/**
 * Main job search function with multi-query strategy
 */
export async function searchJobs(params: JobSearchParams): Promise<SearchResults> {
  const {
    searchKeywords,
    filterKeywords,
    location,
    datePosted,
    minKeywordMatches = 2,
    fuzzyThreshold = 65,
    maxResults = 100,
    tier = 'pro',
    companySearch = false,
    companyName,
  } = params;
  
  // Determine result limit based on tier
  const tierLimits = {
    expert: 30,
    pro: 60,
    superhero: 100,
  };
  const resultLimit = tierLimits[tier];
  
  console.log(`[Search] Tier: ${tier}, Result limit: ${resultLimit}, Company: ${companyName || 'Any'}`);
  
  // Build query combinations
  const queries: string[] = [];
  
  // Individual keywords (top 3)
  for (let i = 0; i < Math.min(3, searchKeywords.length); i++) {
    queries.push(searchKeywords[i]);
  }
  
  // Pairs of keywords
  if (searchKeywords.length >= 2) {
    queries.push(`${searchKeywords[0]} ${searchKeywords[1]}`);
  }
  
  // Three keywords together
  if (searchKeywords.length >= 3) {
    queries.push(`${searchKeywords[0]} ${searchKeywords[1]} ${searchKeywords[2]}`);
  }
  
  console.log(`🔎 Multi-Query Search: ${queries.length} queries`);
  
  // Run all searches
  const allJobs: any[] = [];
  const seenUrls = new Set<string>();
  
  for (const query of queries) {
    console.log(`  Searching: "${query}"`);
    const jobs = await searchSingleQuery(
      query,
      location,
      datePosted,
      companySearch ? companyName : undefined
    );
    
    // Deduplicate by URL
    let newJobs = 0;
    for (const job of jobs) {
      const url = extractJobUrl(job);
      const uniqueKey = url !== 'N/A' ? url : job.job_id;
      
      if (!seenUrls.has(uniqueKey)) {
        seenUrls.add(uniqueKey);
        allJobs.push(job);
        newJobs++;
      }
    }
    
    console.log(`  Found ${jobs.length} jobs (${newJobs} new)`);
  }
  
  console.log(`✅ Total unique jobs found: ${allJobs.length}`);
  
  // Filter jobs by keywords
  const filteredJobs: Job[] = [];
  
  // Use tier-based result limit instead of maxResults
  for (const job of allJobs.slice(0, resultLimit)) {
    const description = job.description || '';
    const keywordAnalysis = countKeywordMatches(description, filterKeywords, fuzzyThreshold);
    
    if (keywordAnalysis.matchCount < minKeywordMatches) {
      continue;
    }
    
    filteredJobs.push({
      jobId: job.job_id || '',
      title: job.title || 'Unknown',
      company: job.company_name || 'Unknown',
      location: job.location || 'Unknown',
      description,
      workStyle: extractWorkStyle(job),
      postingDate: extractPostingDate(job),
      jobUrl: extractJobUrl(job),
      keywordMatches: keywordAnalysis.matchedKeywords,
      matchCount: keywordAnalysis.matchCount,
    });
  }
  
  console.log(`✅ Filtered to ${filteredJobs.length} jobs`);
  
  return {
    jobs: filteredJobs,
    totalFound: allJobs.length,
    totalFiltered: filteredJobs.length,
  };
}

/**
 * Parse resume PDF and extract text
 */
export async function parseResume(pdfBuffer: Buffer): Promise<string> {
  try {
    const data = await (pdfParse as any)(pdfBuffer);
    return data.text;
  } catch (error) {
    console.error('Error parsing PDF:', error);
    throw new Error('Failed to parse resume PDF');
  }
}

/**
 * Generate a tailored cover letter using OpenAI
 */
export async function generateCoverLetter(
  jobTitle: string,
  companyName: string,
  jobDescription: string,
  resumeText: string
): Promise<string> {
  const prompt = `Write a professional, 3-paragraph cover letter for the ${jobTitle} role at ${companyName}.

Job Description:
${jobDescription.substring(0, 2000)}

Candidate's Resume:
${resumeText.substring(0, 2000)}

Write a complete, ready-to-send letter that highlights the most relevant skills and experiences. Be specific and professional.`;

  try {
    const openai = await getOpenAI();
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: 'You are a professional career coach who writes compelling cover letters.',
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      temperature: 0.7,
      max_tokens: 800,
    });

    return completion.choices[0]?.message?.content || 'Failed to generate cover letter';
  } catch (error) {
    console.error('OpenAI error:', error);
    throw new Error('Failed to generate cover letter');
  }
}

