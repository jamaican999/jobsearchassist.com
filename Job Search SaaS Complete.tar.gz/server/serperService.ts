/**
 * Serper.dev API Service
 * Provides job search functionality using Serper.dev's Google Jobs API
 */

interface SerperJobResult {
  title: string;
  company_name: string;
  location: string;
  via: string;
  description: string;
  job_highlights?: Array<{
    title: string;
    items: string[];
  }>;
  related_links?: Array<{
    link: string;
    text: string;
  }>;
  extensions?: string[];
  detected_extensions?: {
    posted_at?: string;
    schedule_type?: string;
  };
  thumbnail?: string;
}

interface SerperResponse {
  jobs_results?: SerperJobResult[];
  search_metadata?: {
    id: string;
    status: string;
    created_at: string;
    processed_at: string;
    total_time_taken: number;
  };
  search_parameters?: {
    q: string;
    location?: string;
    gl?: string;
    hl?: string;
  };
}

export interface JobSearchParams {
  query: string;
  location?: string;
  datePosted?: 'today' | '3days' | 'week' | 'month';
  companyName?: string;
}

export interface JobResult {
  jobId: string;
  title: string;
  company: string;
  location: string;
  description: string;
  postingDate: string;
  jobUrl: string;
  source: string;
}

/**
 * Search for jobs using Serper.dev API
 */
export async function searchJobs(params: JobSearchParams): Promise<JobResult[]> {
  const apiKey = process.env.SERPER_API_KEY;
  
  if (!apiKey) {
    throw new Error('SERPER_API_KEY environment variable is not set');
  }

  // Build search query
  let searchQuery = params.query;
  if (params.companyName) {
    searchQuery += ` at ${params.companyName}`;
  }

  // Build request body
  const requestBody: any = {
    q: searchQuery,
    location: params.location || 'United States',
    gl: 'us',
    hl: 'en',
  };

  // Add date filter if specified
  if (params.datePosted) {
    const dateFilters: Record<string, string> = {
      today: 'today',
      '3days': 'past_3_days',
      week: 'past_week',
      month: 'past_month',
    };
    requestBody.tbs = `qdr:${dateFilters[params.datePosted] || 'w'}`;
  }

  try {
    const response = await fetch('https://google.serper.dev/jobs', {
      method: 'POST',
      headers: {
        'X-API-KEY': apiKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestBody),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Serper API error: ${response.status} - ${errorText}`);
    }

    const data: SerperResponse = await response.json();

    if (!data.jobs_results || data.jobs_results.length === 0) {
      return [];
    }

    // Transform Serper results to our JobResult format
    const jobs: JobResult[] = data.jobs_results.map((job, index) => {
      // Extract posting date
      let postingDate = 'Unknown';
      if (job.detected_extensions?.posted_at) {
        postingDate = job.detected_extensions.posted_at;
      } else if (job.extensions && job.extensions.length > 0) {
        // Sometimes date is in extensions array
        const dateExt = job.extensions.find(ext => 
          ext.toLowerCase().includes('ago') || 
          ext.toLowerCase().includes('today') ||
          ext.toLowerCase().includes('yesterday')
        );
        if (dateExt) {
          postingDate = dateExt;
        }
      }

      // Generate job URL from related links or use a search URL
      let jobUrl = '';
      if (job.related_links && job.related_links.length > 0) {
        jobUrl = job.related_links[0].link;
      } else {
        // Fallback: create a Google Jobs search URL
        const encodedTitle = encodeURIComponent(job.title);
        const encodedCompany = encodeURIComponent(job.company_name);
        jobUrl = `https://www.google.com/search?q=${encodedTitle}+${encodedCompany}+job`;
      }

      return {
        jobId: `serper-${Date.now()}-${index}`,
        title: job.title,
        company: job.company_name,
        location: job.location,
        description: job.description,
        postingDate,
        jobUrl,
        source: job.via || 'Google Jobs',
      };
    });

    return jobs;
  } catch (error) {
    console.error('[Serper] Job search failed:', error);
    throw new Error(`Failed to search jobs: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

/**
 * Get cost estimate for Serper API usage
 * Serper.dev pricing: ~$0.00025 per search (Hobby plan: $50/month for 200k searches)
 */
export function getSerperCostEstimate(searchCount: number): number {
  const costPerSearch = 0.00025;
  return searchCount * costPerSearch;
}

