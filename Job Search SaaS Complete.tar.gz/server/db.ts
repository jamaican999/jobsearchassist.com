import { eq, desc, sql, and, gte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, searchAnalytics, InsertSearchAnalytic, popularSearchTerms, dailyStats, InsertDailyStat } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.id) {
    throw new Error("User ID is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      id: user.id,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role === undefined) {
      if (user.id === ENV.ownerId) {
        user.role = 'admin';
        values.role = 'admin';
        updateSet.role = 'admin';
      }
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUser(id: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Insert a search analytics record
 */
export async function insertSearchAnalytics(data: InsertSearchAnalytic) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot insert search analytics: database not available");
    return;
  }

  try {
    await db.insert(searchAnalytics).values(data);
  } catch (error) {
    console.error("[Database] Failed to insert search analytics:", error);
    throw error;
  }
}

/**
 * Update search analytics with cover letter generation data
 */
export async function updateSearchAnalyticsWithCoverLetters(searchId: string, jobsSelected: number, coverLettersGenerated: number, openaiCost: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update search analytics: database not available");
    return;
  }

  try {
    await db
      .update(searchAnalytics)
      .set({
        jobsSelected,
        coverLettersGenerated,
        openaiCost,
      })
      .where(eq(searchAnalytics.id, searchId));
  } catch (error) {
    console.error("[Database] Failed to update search analytics:", error);
    throw error;
  }
}

/**
 * Update popular search terms
 */
export async function updatePopularSearchTerms(keywords: string[]) {
  const db = await getDb();
  if (!db) return;

  try {
    for (const keyword of keywords) {
      const existing = await db
        .select()
        .from(popularSearchTerms)
        .where(eq(popularSearchTerms.keyword, keyword))
        .limit(1);

      if (existing.length > 0) {
        await db
          .update(popularSearchTerms)
          .set({
            searchCount: sql`${popularSearchTerms.searchCount} + 1`,
            lastSearched: new Date(),
          })
          .where(eq(popularSearchTerms.keyword, keyword));
      } else {
        await db.insert(popularSearchTerms).values({
          id: `term_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          keyword,
          searchCount: 1,
          lastSearched: new Date(),
        });
      }
    }
  } catch (error) {
    console.error("[Database] Failed to update popular search terms:", error);
  }
}

/**
 * Get analytics dashboard data
 */
export async function getDashboardStats() {
  const db = await getDb();
  if (!db) return null;

  try {
    const today = new Date().toISOString().split('T')[0];
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    // Today's stats
    const todayStats = await db
      .select()
      .from(dailyStats)
      .where(eq(dailyStats.date, today))
      .limit(1);

    // This month's stats
    const monthStats = await db
      .select({
        totalSearches: sql<number>`SUM(${dailyStats.totalSearches})`,
        totalRevenue: sql<number>`SUM(${dailyStats.totalRevenue})`,
        uniqueCustomers: sql<number>`SUM(${dailyStats.uniqueCustomers})`,
        repeatCustomers: sql<number>`SUM(${dailyStats.repeatCustomers})`,
        totalCoverLetters: sql<number>`SUM(${dailyStats.totalCoverLetters})`,
        totalCosts: sql<number>`SUM(${dailyStats.totalCosts})`,
      })
      .from(dailyStats)
      .where(gte(dailyStats.date, thirtyDaysAgo));

    // Popular search terms
    const popularTerms = await db
      .select()
      .from(popularSearchTerms)
      .orderBy(desc(popularSearchTerms.searchCount))
      .limit(10);

    // Geographic distribution
    const geoDistribution = await db
      .select({
        country: searchAnalytics.country,
        count: sql<number>`COUNT(*)`,
      })
      .from(searchAnalytics)
      .groupBy(searchAnalytics.country)
      .orderBy(desc(sql`COUNT(*)`))
      .limit(10);

    return {
      today: todayStats[0] || null,
      month: monthStats[0] || null,
      popularTerms,
      geoDistribution,
    };
  } catch (error) {
    console.error("[Database] Failed to get dashboard stats:", error);
    return null;
  }
}

/**
 * Get recent searches for admin view
 */
export async function getRecentSearches(limit: number = 50) {
  const db = await getDb();
  if (!db) return [];

  try {
    return await db
      .select()
      .from(searchAnalytics)
      .orderBy(desc(searchAnalytics.createdAt))
      .limit(limit);
  } catch (error) {
    console.error("[Database] Failed to get recent searches:", error);
    return [];
  }
}

/**
 * Update daily stats (called after each search)
 */
export async function updateDailyStats(data: {
  date: string;
  revenue: number;
  isNewCustomer: boolean;
  isRepeatCustomer: boolean;
  jobsFound: number;
  coverLetters: number;
  costs: number;
  searchDuration: number;
}) {
  const db = await getDb();
  if (!db) return;

  try {
    const existing = await db
      .select()
      .from(dailyStats)
      .where(eq(dailyStats.date, data.date))
      .limit(1);

    if (existing.length > 0) {
      const current = existing[0];
      const newAvgDuration = Math.round(
        (current.avgSearchDuration * current.totalSearches + data.searchDuration) /
          (current.totalSearches + 1)
      );

      await db
        .update(dailyStats)
        .set({
          totalSearches: current.totalSearches + 1,
          totalRevenue: current.totalRevenue + data.revenue,
          uniqueCustomers: current.uniqueCustomers + (data.isNewCustomer ? 1 : 0),
          repeatCustomers: current.repeatCustomers + (data.isRepeatCustomer ? 1 : 0),
          totalJobsFound: current.totalJobsFound + data.jobsFound,
          totalCoverLetters: current.totalCoverLetters + data.coverLetters,
          totalCosts: current.totalCosts + data.costs,
          avgSearchDuration: newAvgDuration,
        })
        .where(eq(dailyStats.date, data.date));
    } else {
      await db.insert(dailyStats).values({
        date: data.date,
        totalSearches: 1,
        totalRevenue: data.revenue,
        uniqueCustomers: data.isNewCustomer ? 1 : 0,
        repeatCustomers: data.isRepeatCustomer ? 1 : 0,
        totalJobsFound: data.jobsFound,
        totalCoverLetters: data.coverLetters,
        totalCosts: data.costs,
        avgSearchDuration: data.searchDuration,
      });
    }
  } catch (error) {
    console.error("[Database] Failed to update daily stats:", error);
  }
}



/**
 * Get search by ID for retry validation
 */
export async function getSearchById(searchId: string) {
  const db = await getDb();
  if (!db) return null;

  try {
    const result = await db
      .select()
      .from(searchAnalytics)
      .where(eq(searchAnalytics.id, searchId))
      .limit(1);
    
    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[Database] Failed to get search by ID:", error);
    return null;
  }
}

/**
 * Increment retry count for a search
 */
export async function incrementRetryCount(searchId: string) {
  const db = await getDb();
  if (!db) return;

  try {
    await db
      .update(searchAnalytics)
      .set({
        retryCount: sql`${searchAnalytics.retryCount} + 1`,
      })
      .where(eq(searchAnalytics.id, searchId));
  } catch (error) {
    console.error("[Database] Failed to increment retry count:", error);
    throw error;
  }
}

/**
 * Update search status and refund info
 */
export async function updateSearchRefundStatus(searchId: string, refundId: string, refundAmount: number) {
  const db = await getDb();
  if (!db) return;

  try {
    await db
      .update(searchAnalytics)
      .set({
        status: 'refunded',
        flaggedForRefund: true,
        refundProcessedAt: new Date(),
        refundAmount,
      })
      .where(eq(searchAnalytics.id, searchId));
  } catch (error) {
    console.error("[Database] Failed to update refund status:", error);
    throw error;
  }
}

