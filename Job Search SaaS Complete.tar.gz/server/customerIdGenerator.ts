/**
 * Generate a unique customer ID in format: JSA-YYYY-XXXXXX
 * 
 * JSA = JobSearchAssist
 * YYYY = Current year
 * XXXXXX = Random 6-character alphanumeric string (uppercase)
 * 
 * Example: JSA-2025-A7B3C9
 */
export function generateCustomerId(): string {
  const year = new Date().getFullYear();
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Removed confusing chars: 0, O, I, 1
  
  let randomPart = '';
  for (let i = 0; i < 6; i++) {
    randomPart += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  
  return `JSA-${year}-${randomPart}`;
}

/**
 * Validate customer ID format
 */
export function isValidCustomerId(customerId: string): boolean {
  const pattern = /^JSA-\d{4}-[A-Z2-9]{6}$/;
  return pattern.test(customerId);
}

