import type Stripe from 'stripe';

// Lazy initialization with dynamic import to defer Stripe loading until runtime
let _stripe: Stripe | null = null;

async function getStripe(): Promise<Stripe> {
  if (!_stripe) {
    const apiKey = process.env.STRIPE_SECRET_KEY;
    if (!apiKey) {
      throw new Error('STRIPE_SECRET_KEY environment variable is not set');
    }
    // Dynamic import to defer loading until runtime
    const { default: StripeClient } = await import('stripe');
    _stripe = new StripeClient(apiKey, {
      apiVersion: '2025-09-30.clover',
    });
  }
  return _stripe;
}

/**
 * Create a Stripe Checkout session for job search payment
 */
export async function createCheckoutSession(params: {
  customerId: string;
  searchId: string;
  amount: number; // Amount in cents
  successUrl: string;
  cancelUrl: string;
  description?: string;
}) {
  const stripe = await getStripe();
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    line_items: [
      {
        price_data: {
          currency: 'usd',
          product_data: {
            name: 'Job Search Assistant',
            description: params.description || 'AI-powered job search with personalized cover letters',
          },
          unit_amount: params.amount,
        },
        quantity: 1,
      },
    ],
    mode: 'payment',
    success_url: params.successUrl,
    cancel_url: params.cancelUrl,
    client_reference_id: params.searchId,
    metadata: {
      customerId: params.customerId,
      searchId: params.searchId,
    },
  });

  return session;
}

/**
 * Create a refund for a failed search
 */
export async function createRefund(paymentIntentId: string, amount: number) {
  const stripe = await getStripe();
  const refund = await stripe.refunds.create({
    payment_intent: paymentIntentId,
    amount, // Amount in cents
    reason: 'requested_by_customer',
  });

  return refund;
}

/**
 * Automatically process refund for failed search
 * Returns true if refund was successful, false if it failed
 */
export async function processAutomaticRefund(params: {
  paymentIntentId: string;
  amount: number;
  customerId: string;
  searchId: string;
}): Promise<{ success: boolean; refundId?: string; error?: string }> {
  try {
    console.log(`[Stripe] Processing automatic refund for customer ${params.customerId}, search ${params.searchId}`);
    
    const refund = await createRefund(params.paymentIntentId, params.amount);
    
    console.log(`[Stripe] Refund successful: ${refund.id} for $${params.amount / 100}`);
    
    return {
      success: true,
      refundId: refund.id,
    };
  } catch (error) {
    console.error('[Stripe] Automatic refund failed:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

/**
 * Retrieve payment intent details
 */
export async function getPaymentIntent(paymentIntentId: string) {
  const stripe = await getStripe();
  const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
  return paymentIntent;
}

/**
 * Retrieve checkout session details
 */
export async function getCheckoutSession(sessionId: string) {
  const stripe = await getStripe();
  const session = await stripe.checkout.sessions.retrieve(sessionId);
  return session;
}

