import { eq, and } from "drizzle-orm";
import { getDb } from "./db";
import { searchAnalytics } from "../drizzle/schema";

/**
 * Update search status to failed and flag for refund
 */
export async function flagSearchForRefund(
  searchId: string,
  errorMessage: string
): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Refund] Cannot flag search: database not available");
    return;
  }

  try {
    await db
      .update(searchAnalytics)
      .set({
        status: "failed",
        errorMessage,
        flaggedForRefund: true,
      })
      .where(eq(searchAnalytics.id, searchId));
    
    console.log(`[Refund] Flagged search ${searchId} for refund: ${errorMessage}`);
  } catch (error) {
    console.error("[Refund] Failed to flag search:", error);
  }
}

/**
 * Update search status to completed
 */
export async function markSearchCompleted(
  searchId: string,
  data: {
    jobsFound: number;
    jobsFiltered: number;
    coverLettersGenerated: number;
    searchDurationMs: number;
  }
): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Search] Cannot update status: database not available");
    return;
  }

  try {
    await db
      .update(searchAnalytics)
      .set({
        status: "completed",
        ...data,
      })
      .where(eq(searchAnalytics.id, searchId));
    
    console.log(`[Search] Marked search ${searchId} as completed`);
  } catch (error) {
    console.error("[Search] Failed to update status:", error);
  }
}

/**
 * Get all searches flagged for refund
 */
export async function getSearchesFlaggedForRefund() {
  const db = await getDb();
  if (!db) {
    console.warn("[Refund] Cannot get flagged searches: database not available");
    return [];
  }

  try {
    const flagged = await db
      .select()
      .from(searchAnalytics)
      .where(
        and(
          eq(searchAnalytics.flaggedForRefund, true),
          eq(searchAnalytics.status, "failed")
        )
      );
    
    return flagged;
  } catch (error) {
    console.error("[Refund] Failed to get flagged searches:", error);
    return [];
  }
}

/**
 * Mark refund as processed
 */
export async function markRefundProcessed(
  searchId: string,
  refundAmount: number
): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Refund] Cannot mark refund: database not available");
    return;
  }

  try {
    await db
      .update(searchAnalytics)
      .set({
        status: "refunded",
        flaggedForRefund: false,
        refundProcessedAt: new Date(),
        refundAmount,
      })
      .where(eq(searchAnalytics.id, searchId));
    
    console.log(`[Refund] Marked refund processed for search ${searchId}`);
  } catch (error) {
    console.error("[Refund] Failed to mark refund:", error);
  }
}

/**
 * Process all pending refunds (batch job)
 * This would typically be called by a cron job or scheduled task
 */
export async function processPendingRefunds(): Promise<{
  processed: number;
  failed: number;
  totalAmount: number;
}> {
  const flaggedSearches = await getSearchesFlaggedForRefund();
  
  let processed = 0;
  let failed = 0;
  let totalAmount = 0;

  console.log(`[Refund Batch] Processing ${flaggedSearches.length} refunds...`);

  for (const search of flaggedSearches) {
    try {
      // TODO: Integrate with Stripe refund API
      // const refund = await stripe.refunds.create({
      //   payment_intent: search.stripePaymentId,
      //   reason: 'requested_by_customer',
      // });

      // For now, just mark as processed
      await markRefundProcessed(search.id, search.revenue);
      
      processed++;
      totalAmount += search.revenue;
      
      console.log(`[Refund] Processed refund for ${search.customerId}: $${search.revenue / 100}`);
    } catch (error) {
      console.error(`[Refund] Failed to process refund for ${search.customerId}:`, error);
      failed++;
    }
  }

  console.log(`[Refund Batch] Complete: ${processed} processed, ${failed} failed, $${totalAmount / 100} total`);

  return {
    processed,
    failed,
    totalAmount,
  };
}

