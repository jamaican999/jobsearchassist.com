import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { searchJobs, parseResume, generateCoverLetter, type Job } from "./jobSearchService";
import { insertSearchAnalytics, updateSearchAnalyticsWithCoverLetters, updatePopularSearchTerms, getDashboardStats, getRecentSearches, updateDailyStats } from "./db";
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const geoip = require('geoip-lite');
import { randomUUID } from "crypto";
import { generateCustomerId } from "./customerIdGenerator";
import { flagSearchForRefund, markSearchCompleted, getSearchesFlaggedForRefund, processPendingRefunds } from "./refundService";
import { createCheckoutSession, getCheckoutSession, processAutomaticRefund } from "./stripeService";
import { storagePut, storageGet } from "./storage";
import { TRPCError } from "@trpc/server";

// Admin-only procedure
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== 'admin') {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Admin access required' });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Payment procedures
  payment: router({
    /**
     * Create a Stripe Checkout session
     */
    createCheckoutSession: publicProcedure
      .input(
        z.object({
          customerId: z.string(),
          searchId: z.string(),
          tier: z.enum(['expert', 'pro', 'superhero']),
          companySearch: z.boolean(),
          companyName: z.string().optional(),
          searchParams: z.object({
            searchKeywords: z.array(z.string()),
            filterKeywords: z.array(z.string()),
            location: z.string().optional(),
            datePosted: z.string().optional(),
            minKeywordMatches: z.number(),
            enableBatch2: z.boolean().optional(),
            searchKeywords2: z.array(z.string()).optional(),
            filterKeywords2: z.array(z.string()).optional(),
          }),
        })
      )
      .mutation(async ({ input, ctx }) => {
        try {
          const baseUrl = process.env.VITE_APP_URL || `${ctx.req.protocol}://${ctx.req.get('host')}`;
          
          // Calculate total price based on tier and add-ons
          const tierPrices = { expert: 10, pro: 25, superhero: 40 };
          const companySearchPrice = 2.50;
          const totalPrice = tierPrices[input.tier] + (input.companySearch ? companySearchPrice : 0);
          
          const session = await createCheckoutSession({
            customerId: input.customerId,
            searchId: input.searchId,
            amount: Math.round(totalPrice * 100), // Convert to cents
            successUrl: `${baseUrl}/app?payment=success&session_id={CHECKOUT_SESSION_ID}&search_id=${input.searchId}`,
            cancelUrl: `${baseUrl}/app?payment=cancelled`,
          });

          return {
            sessionId: session.id,
            url: session.url,
          };
        } catch (error) {
          console.error('[Payment] Error creating checkout session:', error);
          throw new TRPCError({
            code: 'INTERNAL_SERVER_ERROR',
            message: 'Failed to create payment session',
          });
        }
      }),

    /**
     * Verify payment completion
     */
    verifyPayment: publicProcedure
      .input(
        z.object({
          sessionId: z.string(),
        })
      )
      .query(async ({ input }) => {
        try {
          const session = await getCheckoutSession(input.sessionId);
          
          return {
            paid: session.payment_status === 'paid',
            customerId: session.metadata?.customerId || null,
            searchId: session.client_reference_id || null,
            paymentIntentId: session.payment_intent as string || null,
          };
        } catch (error) {
          console.error('[Payment] Error verifying payment:', error);
          throw new TRPCError({
            code: 'INTERNAL_SERVER_ERROR',
            message: 'Failed to verify payment',
          });
        }
      }),
  }),

  // Job search procedures
  jobs: router({
    /**
     * Search for jobs
     */
    search: publicProcedure
      .input(
        z.object({
          searchKeywords: z.array(z.string()).min(1),
          filterKeywords: z.array(z.string()).min(1),
          location: z.string().optional(),
          datePosted: z.enum(['today', '3days', 'week', 'month']).optional(),
          minKeywordMatches: z.number().default(2),
          fuzzyThreshold: z.number().default(65),
          // Pricing tier (determines result limit)
          tier: z.enum(['expert', 'pro', 'superhero']).optional().default('pro'),
          // Company search add-on
          companySearch: z.boolean().optional(),
          companyName: z.string().optional(),
          // Batch 2 parameters
          enableBatch2: z.boolean().optional(),
          searchKeywords2: z.array(z.string()).optional(),
          filterKeywords2: z.array(z.string()).optional(),
          // Payment info for retry/refund
          paymentIntentId: z.string().optional(),
          sessionId: z.string().optional(),
          revenue: z.number().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const startTime = Date.now();
        let searchId = randomUUID();
        let customerId = generateCustomerId();
        
        // Calculate search expiration (30 minutes from now)
        const searchExpiresAt = new Date(Date.now() + 30 * 60 * 1000);
        const browserSessionId = ctx.req.headers['x-session-id'] as string || null;
        
        try {
          // Search for jobs with retry logic
          let results;
          let attempts = 0;
          const maxAttempts = 3;
          
          while (attempts < maxAttempts) {
            try {
              // Run Batch 1 search
              const batch1Results = await searchJobs(input);
              
              // Run Batch 2 search if enabled
              if (input.enableBatch2 && input.searchKeywords2 && input.filterKeywords2) {
                const batch2Input = {
                  ...input,
                  searchKeywords: input.searchKeywords2,
                  filterKeywords: input.filterKeywords2,
                };
                const batch2Results = await searchJobs(batch2Input);
                
                // Merge results and remove duplicates by jobId
                const allJobs = [...batch1Results.jobs, ...batch2Results.jobs];
                const uniqueJobs = Array.from(
                  new Map(allJobs.map(job => [job.jobId, job])).values()
                );
                
                results = {
                  jobs: uniqueJobs,
                  totalFound: batch1Results.totalFound + batch2Results.totalFound,
                  totalFiltered: uniqueJobs.length,
                };
              } else {
                results = batch1Results;
              }
              
              break; // Success!
            } catch (error) {
              attempts++;
              console.log(`[Search] Attempt ${attempts}/${maxAttempts} failed`);
              if (attempts < maxAttempts) {
                await new Promise(resolve => setTimeout(resolve, 5000)); // Wait 5s
              } else {
                throw error; // Give up after 3 attempts
              }
            }
          }
          
          if (!results || results.jobs.length === 0) {
            throw new Error('No jobs found matching your criteria');
          }
          
          const duration = Date.now() - startTime;
          
          // Get location from IP
          const ip = ctx.req.headers['x-forwarded-for'] as string || ctx.req.socket.remoteAddress || '';
          const cleanIp = ip.split(',')[0].trim();
          const geo = geoip.lookup(cleanIp);
          const userAgent = ctx.req.headers['user-agent'] || null;
          
          // Track analytics
          await insertSearchAnalytics({
            id: searchId,
            customerId,
            createdAt: new Date(),
            stripeCustomerId: null,
            stripePaymentId: null,
            paymentIntentId: input.paymentIntentId || null,
            revenue: input.revenue || 2499, // Amount in cents
            sessionId: browserSessionId,
            searchExpiresAt,
            retryCount: 0,
            country: geo?.country || null,
            state: geo?.region || null,
            userIp: cleanIp,
            userAgent: userAgent,
            searchKeywords: input.enableBatch2 
              ? `Batch1: ${input.searchKeywords.join(', ')} | Batch2: ${input.searchKeywords2?.join(', ')}` 
              : input.searchKeywords.join(', '),
            filterKeywords: input.enableBatch2
              ? `Batch1: ${input.filterKeywords.join(', ')} | Batch2: ${input.filterKeywords2?.join(', ')}`
              : input.filterKeywords.join(', '),
            minMatches: input.minKeywordMatches || 2,
            dateFilter: input.datePosted || null,
            jobsFound: results.totalFound,
            jobsFiltered: results.totalFiltered,
            jobsSelected: 0, // Will be updated when user generates cover letters
            coverLettersGenerated: 0,
            searchDurationMs: duration,
            status: 'completed',
            errorMessage: null,
            flaggedForRefund: false,
            openaiCost: null,
            serpapiCost: input.enableBatch2 
              ? Math.round((input.searchKeywords.length + (input.searchKeywords2?.length || 0)) * 50) 
              : Math.round(input.searchKeywords.length * 50), // Estimate: $0.50 per query
            stripeFee: null,
          });
          
          // Update popular search terms
          await updatePopularSearchTerms(input.searchKeywords);
          
          return {
            searchId,
            customerId,
            ...results,
          };
        } catch (error) {
          console.error('Job search error:', error);
          
          const errorMessage = error instanceof Error ? error.message : 'Unknown error';
          
          // Flag for automatic refund
          await flagSearchForRefund(searchId, errorMessage);
          
          // Process automatic refund immediately if payment was made
          if (input.paymentIntentId && input.revenue) {
            console.log(`[Refund] Triggering automatic refund for failed search ${searchId}`);
            const refundResult = await processAutomaticRefund({
              paymentIntentId: input.paymentIntentId,
              amount: input.revenue,
              customerId,
              searchId,
            });
            
            if (refundResult.success) {
              console.log(`[Refund] Automatic refund successful: ${refundResult.refundId}`);
            } else {
              console.error(`[Refund] Automatic refund failed: ${refundResult.error}`);
            }
          }
          
          throw new TRPCError({
            code: 'INTERNAL_SERVER_ERROR',
            message: 'Search failed. Your payment has been automatically refunded.',
          });
        }
      }),

    /**
     * Upload resume and parse it
     */
    uploadResume: publicProcedure
      .input(
        z.object({
          fileData: z.string(), // Base64 encoded PDF
          fileName: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        try {
          const buffer = Buffer.from(input.fileData, 'base64');
          const resumeText = await parseResume(buffer);
          
          // Store resume temporarily (1 hour expiration)
          const resumeId = randomUUID();
          const { key, url } = await storagePut(
            `resumes/${resumeId}.pdf`,
            buffer,
            'application/pdf'
          );
          
          return {
            resumeId,
            resumeText: resumeText.substring(0, 3000), // Truncate for client
            resumeUrl: url,
          };
        } catch (error) {
          console.error('Resume upload error:', error);
          throw new TRPCError({
            code: 'BAD_REQUEST',
            message: 'Failed to parse resume. Please ensure it is a valid PDF.',
          });
        }
      }),

    /**
     * Generate cover letters for selected jobs
     */
    generateCoverLetters: publicProcedure
      .input(
        z.object({
          searchId: z.string(),
          resumeText: z.string(),
          selectedJobs: z.array(
            z.object({
              jobId: z.string(),
              title: z.string(),
              company: z.string(),
              description: z.string(),
              location: z.string(),
              workStyle: z.enum(['Remote', 'Hybrid', 'In-Office']),
              postingDate: z.string(),
              jobUrl: z.string(),
              keywordMatches: z.array(z.string()),
              matchCount: z.number(),
            })
          ),
        })
      )
      .mutation(async ({ input }) => {
        try {
          const coverLetters: Array<{
            jobId: string;
            jobTitle: string;
            company: string;
            coverLetter: string;
            fileName: string;
          }> = [];

          // Generate cover letters
          for (const job of input.selectedJobs) {
            console.log(`Generating cover letter for ${job.title} at ${job.company}...`);
            
            const coverLetter = await generateCoverLetter(
              job.title,
              job.company,
              job.description,
              input.resumeText
            );

            coverLetters.push({
              jobId: job.jobId,
              jobTitle: job.title,
              company: job.company,
              coverLetter,
              fileName: `cover_letter_${job.company.replace(/[^a-z0-9]/gi, '_')}.txt`,
            });
          }

          // Store cover letters temporarily
          const sessionId = randomUUID();
          const files: Array<{ name: string; url: string }> = [];
          
          for (const cl of coverLetters) {
            const { url } = await storagePut(
              `cover-letters/${sessionId}/${cl.fileName}`,
              Buffer.from(cl.coverLetter, 'utf-8'),
              'text/plain'
            );
            files.push({ name: cl.fileName, url });
          }

          // Generate CSV report
          const csvRows = [
            ['Company', 'Job Title', 'Location', 'Work Style', 'Posted Date', 'Job URL', 'Keywords Matched', 'Match Count'].join(',')
          ];

          for (const job of input.selectedJobs) {
            csvRows.push([
              `"${job.company}"`,
              `"${job.title}"`,
              `"${job.location}"`,
              job.workStyle,
              `"${job.postingDate}"`,
              job.jobUrl,
              `"${job.keywordMatches.join('; ')}"`,
              job.matchCount.toString(),
            ].join(','));
          }

          const csvContent = csvRows.join('\n');
          const { url: csvUrl } = await storagePut(
            `cover-letters/${sessionId}/job_report.csv`,
            Buffer.from(csvContent, 'utf-8'),
            'text/csv'
          );

          files.push({ name: 'job_report.csv', url: csvUrl });

          // Update analytics with cover letter data
          const openaiCost = coverLetters.length * 20; // $0.20 per letter in cents
          await updateSearchAnalyticsWithCoverLetters(
            input.searchId,
            input.selectedJobs.length,
            coverLetters.length,
            openaiCost
          );
          
          return {
            sessionId,
            files,
            coverLettersGenerated: coverLetters.length,
            estimatedCost: openaiCost,
          };
        } catch (error) {
          console.error('Cover letter generation error:', error);
          throw new TRPCError({
            code: 'INTERNAL_SERVER_ERROR',
            message: 'Failed to generate cover letters',
          });
        }
      }),

    /**
     * Retry a failed search
     */
    retrySearch: publicProcedure
      .input(
        z.object({
          searchId: z.string(),
          sessionId: z.string(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const { getSearchById, incrementRetryCount, updateSearchRefundStatus } = await import('./db');
        
        // Get the original search
        const originalSearch = await getSearchById(input.searchId);
        
        if (!originalSearch) {
          throw new TRPCError({
            code: 'NOT_FOUND',
            message: 'Search not found',
          });
        }
        
        // Validate retry eligibility
        const now = new Date();
        const searchExpired = originalSearch.searchExpiresAt && new Date(originalSearch.searchExpiresAt) < now;
        const sessionMismatch = originalSearch.sessionId !== input.sessionId;
        
        if (searchExpired && sessionMismatch) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Retry window expired (30 minutes) and session mismatch',
          });
        }
        
        // Check retry count
        if (originalSearch.retryCount >= 2) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'Maximum retry attempts reached. Refund has been processed.',
          });
        }
        
        // Increment retry count
        await incrementRetryCount(input.searchId);
        
        // Attempt the search again
        try {
          const searchParams = {
            searchKeywords: originalSearch.searchKeywords?.split(', ') || [],
            filterKeywords: originalSearch.filterKeywords?.split(', ') || [],
            location: undefined,
            datePosted: originalSearch.dateFilter as any,
            minKeywordMatches: originalSearch.minMatches || 2,
            fuzzyThreshold: 65,
            tier: 'pro' as const,
            paymentIntentId: originalSearch.paymentIntentId || undefined,
            revenue: originalSearch.revenue,
          };
          
          const results = await searchJobs(searchParams);
          
          if (!results || results.jobs.length === 0) {
            throw new Error('No jobs found matching your criteria');
          }
          
          // Update status to completed
          await markSearchCompleted(input.searchId, {
            jobsFound: results.totalFound,
            jobsFiltered: results.totalFiltered,
            coverLettersGenerated: 0,
            searchDurationMs: 0,
          });
          
          return {
            success: true,
            searchId: input.searchId,
            customerId: originalSearch.customerId,
            ...results,
          };
        } catch (error) {
          console.error('Retry search error:', error);
          
          // Check if this was the 2nd retry
          const updatedSearch = await getSearchById(input.searchId);
          if (updatedSearch && updatedSearch.retryCount >= 2) {
            // Max retries reached, ensure refund is processed
            if (originalSearch.paymentIntentId && originalSearch.revenue) {
              const refundResult = await processAutomaticRefund({
                paymentIntentId: originalSearch.paymentIntentId,
                amount: originalSearch.revenue,
                customerId: originalSearch.customerId,
                searchId: input.searchId,
              });
              
              if (refundResult.success && refundResult.refundId) {
                await updateSearchRefundStatus(input.searchId, refundResult.refundId, originalSearch.revenue);
              }
            }
            
            throw new TRPCError({
              code: 'INTERNAL_SERVER_ERROR',
              message: 'Maximum retry attempts reached. Your payment has been refunded.',
            });
          }
          
          throw new TRPCError({
            code: 'INTERNAL_SERVER_ERROR',
            message: 'Retry failed. You can try again.',
          });
        }
      }),
  }),

  // Admin analytics procedures
  admin: router({
    /**
     * Get dashboard statistics
     */
    getDashboardStats: adminProcedure.query(async () => {
      const stats = await getDashboardStats();
      const flaggedSearches = await getSearchesFlaggedForRefund();
      
      if (!stats) {
        return {
          totalSearches: 0,
          completedSearches: 0,
          failedSearches: 0,
          flaggedForRefund: 0,
          refundedSearches: 0,
          totalRevenue: 0,
          totalRefunded: 0,
        };
      }
      
      return {
        totalSearches: stats.today.totalSearches + stats.month.totalSearches,
        completedSearches: stats.today.totalSearches,
        failedSearches: flaggedSearches.length,
        flaggedForRefund: flaggedSearches.filter(s => s.flaggedForRefund).length,
        refundedSearches: flaggedSearches.filter(s => s.status === 'refunded').length,
        totalRevenue: stats.today.totalRevenue + stats.month.totalRevenue,
        totalRefunded: flaggedSearches
          .filter(s => s.status === 'refunded')
          .reduce((sum, s) => sum + (s.refundAmount || 0), 0),
      };
    }),
    
    getDashboard: adminProcedure.query(async () => {
      const stats = await getDashboardStats();
      return stats || null;
    }),
    
    getRecentSearches: adminProcedure
      .input(z.object({ limit: z.number().default(50).optional() }).optional())
      .query(async ({ input }) => {
        const searches = await getRecentSearches(input?.limit || 50);
        return searches;
      }),
    
    processRefunds: adminProcedure.mutation(async () => {
      const result = await processPendingRefunds();
      return result;
    }),
  }),
});

export type AppRouter = typeof appRouter;
