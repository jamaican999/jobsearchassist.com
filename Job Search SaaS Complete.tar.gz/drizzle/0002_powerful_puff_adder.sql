ALTER TABLE `search_analytics` MODIFY COLUMN `status` enum('pending','completed','failed','refunded') NOT NULL DEFAULT 'pending';--> statement-breakpoint
ALTER TABLE `search_analytics` ADD `customerId` varchar(32) NOT NULL;--> statement-breakpoint
ALTER TABLE `search_analytics` ADD `flaggedForRefund` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `search_analytics` ADD `refundProcessedAt` timestamp;--> statement-breakpoint
ALTER TABLE `search_analytics` ADD `refundAmount` int;