ALTER TABLE `search_analytics` ADD `userIp` varchar(45);--> statement-breakpoint
ALTER TABLE `search_analytics` ADD `userAgent` text;--> statement-breakpoint
ALTER TABLE `search_analytics` ADD `minMatches` int DEFAULT 2;--> statement-breakpoint
ALTER TABLE `search_analytics` ADD `jobsSelected` int DEFAULT 0 NOT NULL;