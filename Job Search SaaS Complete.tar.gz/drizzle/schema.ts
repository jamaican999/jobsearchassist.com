import { mysqlEnum, mysqlTable, text, timestamp, varchar, int, decimal, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: varchar("id", { length: 64 }).primaryKey(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Search analytics - tracks each job search session
 * Privacy-first: no PII, just business metrics
 */
export const searchAnalytics = mysqlTable("search_analytics", {
  id: varchar("id", { length: 64 }).primaryKey(),
  customerId: varchar("customerId", { length: 32 }).notNull(), // JSA-2025-XXXXXX format for customer reference
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  
  // Payment info
  stripeCustomerId: varchar("stripeCustomerId", { length: 255 }), // Hashed for repeat customer tracking
  stripePaymentId: varchar("stripePaymentId", { length: 255 }),
  paymentIntentId: varchar("paymentIntentId", { length: 255 }), // For Stripe refunds
  revenue: int("revenue").notNull(), // In cents (e.g., 2499 = $24.99)
  
  // Location & Device Info
  country: varchar("country", { length: 2 }), // ISO country code (e.g., "US")
  state: varchar("state", { length: 50 }), // State/province (optional)
  userIp: varchar("userIp", { length: 45 }), // IPv4 or IPv6 for debugging
  userAgent: text("userAgent"), // Browser/device info for support
  
  // Search details
  searchKeywords: text("searchKeywords"), // Comma-separated keywords searched
  filterKeywords: text("filterKeywords"), // Comma-separated filter keywords
  minMatches: int("minMatches").default(2), // Minimum keyword matches required
  dateFilter: varchar("dateFilter", { length: 20 }), // "today", "week", etc.
  
  // Results
  jobsFound: int("jobsFound").default(0).notNull(),
  jobsFiltered: int("jobsFiltered").default(0).notNull(),
  jobsSelected: int("jobsSelected").default(0).notNull(), // How many jobs user selected for cover letters
  coverLettersGenerated: int("coverLettersGenerated").default(0).notNull(),
  
  // Performance
  searchDurationMs: int("searchDurationMs"), // How long the search took
  status: mysqlEnum("status", ["pending", "completed", "failed", "refunded"]).default("pending").notNull(),
  errorMessage: text("errorMessage"), // If failed, why?
  
  // Retry tracking
  retryCount: int("retryCount").default(0).notNull(), // Number of retry attempts
  sessionId: varchar("sessionId", { length: 255 }), // Browser session ID for retry validation
  searchExpiresAt: timestamp("searchExpiresAt"), // Payment time + 30 minutes for retry window
  
  // Refund tracking
  flaggedForRefund: boolean("flaggedForRefund").default(false).notNull(),
  refundProcessedAt: timestamp("refundProcessedAt"),
  refundAmount: int("refundAmount"), // In cents
  
  // Costs (calculated)
  openaiCost: int("openaiCost"), // In cents
  serpapiCost: int("serpapiCost"), // In cents
  stripeFee: int("stripeFee"), // In cents
});

export type SearchAnalytic = typeof searchAnalytics.$inferSelect;
export type InsertSearchAnalytic = typeof searchAnalytics.$inferInsert;

/**
 * Popular search terms - aggregated data
 */
export const popularSearchTerms = mysqlTable("popular_search_terms", {
  id: varchar("id", { length: 64 }).primaryKey(),
  keyword: varchar("keyword", { length: 255 }).notNull().unique(),
  searchCount: int("searchCount").default(0).notNull(),
  lastSearched: timestamp("lastSearched").defaultNow(),
});

export type PopularSearchTerm = typeof popularSearchTerms.$inferSelect;
export type InsertPopularSearchTerm = typeof popularSearchTerms.$inferInsert;

/**
 * Daily aggregated stats for dashboard
 */
export const dailyStats = mysqlTable("daily_stats", {
  date: varchar("date", { length: 10 }).primaryKey(), // YYYY-MM-DD
  totalSearches: int("totalSearches").default(0).notNull(),
  totalRevenue: int("totalRevenue").default(0).notNull(), // In cents
  uniqueCustomers: int("uniqueCustomers").default(0).notNull(),
  repeatCustomers: int("repeatCustomers").default(0).notNull(),
  totalJobsFound: int("totalJobsFound").default(0).notNull(),
  totalCoverLetters: int("totalCoverLetters").default(0).notNull(),
  totalCosts: int("totalCosts").default(0).notNull(), // In cents
  avgSearchDuration: int("avgSearchDuration").default(0).notNull(), // In ms
});

export type DailyStat = typeof dailyStats.$inferSelect;
export type InsertDailyStat = typeof dailyStats.$inferInsert;

