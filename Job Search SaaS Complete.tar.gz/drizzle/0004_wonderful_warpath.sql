ALTER TABLE `search_analytics` ADD `paymentIntentId` varchar(255);--> statement-breakpoint
ALTER TABLE `search_analytics` ADD `retryCount` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `search_analytics` ADD `sessionId` varchar(255);--> statement-breakpoint
ALTER TABLE `search_analytics` ADD `searchExpiresAt` timestamp;