CREATE TABLE `daily_stats` (
	`date` varchar(10) NOT NULL,
	`totalSearches` int NOT NULL DEFAULT 0,
	`totalRevenue` int NOT NULL DEFAULT 0,
	`uniqueCustomers` int NOT NULL DEFAULT 0,
	`repeatCustomers` int NOT NULL DEFAULT 0,
	`totalJobsFound` int NOT NULL DEFAULT 0,
	`totalCoverLetters` int NOT NULL DEFAULT 0,
	`totalCosts` int NOT NULL DEFAULT 0,
	`avgSearchDuration` int NOT NULL DEFAULT 0,
	CONSTRAINT `daily_stats_date` PRIMARY KEY(`date`)
);
--> statement-breakpoint
CREATE TABLE `popular_search_terms` (
	`id` varchar(64) NOT NULL,
	`keyword` varchar(255) NOT NULL,
	`searchCount` int NOT NULL DEFAULT 0,
	`lastSearched` timestamp DEFAULT (now()),
	CONSTRAINT `popular_search_terms_id` PRIMARY KEY(`id`),
	CONSTRAINT `popular_search_terms_keyword_unique` UNIQUE(`keyword`)
);
--> statement-breakpoint
CREATE TABLE `search_analytics` (
	`id` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`stripeCustomerId` varchar(255),
	`stripePaymentId` varchar(255),
	`revenue` int NOT NULL,
	`country` varchar(2),
	`state` varchar(50),
	`searchKeywords` text,
	`filterKeywords` text,
	`dateFilter` varchar(20),
	`jobsFound` int NOT NULL DEFAULT 0,
	`jobsFiltered` int NOT NULL DEFAULT 0,
	`coverLettersGenerated` int NOT NULL DEFAULT 0,
	`searchDurationMs` int,
	`status` enum('completed','failed','abandoned') NOT NULL DEFAULT 'completed',
	`errorMessage` text,
	`openaiCost` int,
	`serpapiCost` int,
	`stripeFee` int,
	CONSTRAINT `search_analytics_id` PRIMARY KEY(`id`)
);
