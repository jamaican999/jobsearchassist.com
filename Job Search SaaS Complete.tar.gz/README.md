# JobSearchAssist.org - Job Search Agent SaaS

A full-stack web application that helps job seekers play the numbers game by automating job searches and generating personalized cover letters using AI.

## 🚀 Features

- **AI-Powered Job Matching**: Intelligent keyword matching against job postings
- **Personalized Cover Letters**: Automatically generate customized cover letters for each job
- **Three Pricing Tiers**: Expert ($10), Pro ($25), Superhero ($40) with 30-100 job matches
- **Stripe Payment Integration**: Secure payment processing with automatic refunds on failure
- **Retry Mechanism**: Users can retry failed searches within 30 minutes or same session
- **User Authentication**: Manus OAuth integration for secure user management
- **Admin Dashboard**: Role-based access control for admin users
- **Responsive Design**: Mobile-first design with Tailwind CSS 4
- **Database Tracking**: Complete search analytics and user management

## 🛠️ Tech Stack

### Frontend
- **React 19** - Modern UI library
- **TypeScript** - Type-safe development
- **Tailwind CSS 4** - Utility-first styling
- **tRPC 11** - End-to-end typesafe APIs
- **Wouter** - Lightweight routing
- **shadcn/ui** - Beautiful component library

### Backend
- **Node.js** - Runtime environment
- **Express 4** - Web framework
- **tRPC 11** - API layer
- **Drizzle ORM** - Type-safe database queries
- **MySQL/TiDB** - Database
- **Stripe** - Payment processing

### Infrastructure
- **Vite** - Fast build tool
- **pnpm** - Fast package manager
- **tsx** - TypeScript execution

## 📋 Prerequisites

- Node.js 22.x or higher
- pnpm 9.x or higher
- MySQL or TiDB database
- Stripe account (for payments)
- Manus OAuth credentials

## 🔧 Installation

1. **Clone the repository**
```bash
git clone <your-repo-url>
cd job-search-saas
```

2. **Install dependencies**
```bash
pnpm install
```

3. **Set up environment variables**

Create a `.env` file in the root directory with the following variables:

```env
# Database
DATABASE_URL=mysql://user:password@host:port/database

# Authentication
JWT_SECRET=your-jwt-secret-here
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im
OWNER_OPEN_ID=your-owner-open-id
OWNER_NAME=Your Name

# Stripe
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...

# Application
VITE_APP_ID=your-app-id
VITE_APP_TITLE=JobSearchAssist.org
VITE_APP_LOGO=/logo.svg
VITE_APP_URL=http://localhost:3000

# Manus Built-in APIs
BUILT_IN_FORGE_API_URL=https://forge.manus.im
BUILT_IN_FORGE_API_KEY=your-forge-api-key

# Search APIs (choose one or both)
SERPAPI_API_KEY=your-serpapi-key
SERPER_API_KEY=your-serper-key

# Analytics (optional)
VITE_ANALYTICS_ENDPOINT=your-analytics-endpoint
VITE_ANALYTICS_WEBSITE_ID=your-website-id
```

4. **Initialize the database**
```bash
pnpm db:push
```

5. **Start the development server**
```bash
pnpm dev
```

The application will be available at `http://localhost:3000`

## 📦 Project Structure

```
job-search-saas/
├── client/                 # Frontend React application
│   ├── public/            # Static assets
│   ├── src/
│   │   ├── pages/         # Page components
│   │   ├── components/    # Reusable UI components
│   │   ├── contexts/      # React contexts
│   │   ├── hooks/         # Custom hooks
│   │   ├── lib/           # Utilities and tRPC client
│   │   ├── App.tsx        # Main app component
│   │   └── main.tsx       # Entry point
├── server/                # Backend Express + tRPC
│   ├── _core/             # Core framework code
│   ├── db.ts              # Database queries
│   ├── routers.ts         # tRPC routes
│   ├── stripeService.ts   # Stripe integration
│   └── refundService.ts   # Refund logic
├── drizzle/               # Database schema and migrations
│   └── schema.ts          # Table definitions
├── shared/                # Shared types and constants
├── storage/               # S3 storage helpers
└── package.json           # Dependencies and scripts
```

## 🚀 Deployment

### Build for Production

```bash
pnpm build
```

### Start Production Server

```bash
pnpm start
```

### Environment Configuration

Make sure to update the following environment variables for production:

- `VITE_APP_URL` - Your production domain
- `DATABASE_URL` - Production database connection
- `STRIPE_SECRET_KEY` - Live Stripe key (not test key)
- All other API keys should use production values

## 🔑 Key Features Explained

### Automatic Refund System

- Searches that fail trigger immediate Stripe refunds
- Users can retry within 30 minutes OR same browser session
- Maximum 2 retry attempts before permanent refund
- No manual intervention required

### Cancel & Retry Buttons

- **Cancel Button**: Resets form state before payment
- **Retry Button**: Appears only for failed searches, validates session/time constraints

### Pricing Display

- Condensed pricing selector at top of search form
- Pricing preview on landing page before CTA button
- Three tiers with clear feature differentiation
- User testimonials for social proof

### Database Schema

Key tables:
- `users` - User authentication and roles
- `search_analytics` - Search tracking, retry counts, payment intents
- Additional tables for job results and cover letters

## 📝 Scripts

- `pnpm dev` - Start development server
- `pnpm build` - Build for production
- `pnpm start` - Start production server
- `pnpm db:push` - Push schema changes to database
- `pnpm db:studio` - Open Drizzle Studio (database GUI)

## 🔒 Security Notes

- Never commit `.env` files to version control
- Use environment variables for all secrets
- Stripe webhooks should be configured for production
- Database credentials should be rotated regularly
- JWT secrets should be strong and unique

## 📄 License

[Your License Here]

## 🤝 Contributing

[Your contribution guidelines here]

## 📧 Support

For support, email [your-email] or visit [your-support-url]

## 🙏 Acknowledgments

- Built with [Manus](https://manus.im) platform
- UI components from [shadcn/ui](https://ui.shadcn.com)
- Icons from [Lucide](https://lucide.dev)

---

**Note**: This application requires active subscriptions/API keys for:
- Manus OAuth and Forge APIs
- Stripe payment processing
- SerpAPI or Serper for job search data
- MySQL/TiDB database hosting

