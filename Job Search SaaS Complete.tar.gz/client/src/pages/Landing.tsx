import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { Briefcase, Shield, FileText, TrendingUp } from "lucide-react";

export default function Landing() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Briefcase className="h-8 w-8 text-blue-600" />
            <span className="text-xl font-bold text-gray-900">JobSearchAssist.org</span>
          </div>
          <p className="text-sm text-gray-600 hidden sm:block">Play the numbers game</p>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 md:py-24 text-center">
        <h1 className="text-4xl md:text-6xl font-bold text-blue-600 mb-6">
          Let <span className="text-3xl md:text-5xl italic text-blue-500">jobsearchassist.org</span> help you play the numbers game.
        </h1>
        
        {/* Privacy Network Graphic Placeholder */}
        <div className="max-w-3xl mx-auto my-12 p-8 bg-gray-900 rounded-lg relative overflow-hidden">
          <div className="absolute inset-0 opacity-20">
            <div className="grid grid-cols-8 gap-4 h-full">
              {Array.from({ length: 64 }).map((_, i) => (
                <div key={i} className="border border-pink-500/30 rounded" />
              ))}
            </div>
          </div>
          <div className="relative z-10 space-y-4 text-white">
            <div className="text-sm opacity-70">[[privacy]]</div>
            <div className="text-sm opacity-70">[[efficiency]]</div>
            <div className="text-sm opacity-70">[[personalization]]</div>
            <div className="text-2xl font-bold">Your data stays private</div>
          </div>
        </div>

        <h2 className="text-3xl md:text-4xl font-bold text-blue-700 mb-8">
          About JobSearchAssist.org
        </h2>
        
        <p className="text-xl md:text-2xl text-gray-700 mb-4 max-w-3xl mx-auto">
          Accept no substitutes! If it's not jobsearchassist.ORG, its not the real thing.
        </p>
      </section>

      {/* Value Proposition */}
      <section className="bg-white py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-blue-700 mb-8 text-center">
            Navigating the Numbers Game: Transforming Job Searching with jobsearchassist.org
          </h2>
          
          <div className="max-w-3xl mx-auto space-y-6 text-lg text-gray-700">
            <p className="text-xl font-semibold text-center">
              Did you know that only 3 out of every 100 job applications receive responses????
            </p>
            
            <p className="text-center">
              The struggle is real, but there's a new way to beat these odds and find relevant, tailored job openings faster!
            </p>
            
            <p className="text-center italic">
              Meet <span className="font-bold text-blue-600">jobsearchassist.org</span>
            </p>
            
            <p className="text-center">
              In a marketplace obsessed with metrics, <span className="font-bold text-blue-600">jobsearchassist.org</span> is your ally —— a game-changer in the job search world.
            </p>
            
            <p className="text-center italic">
              with a tailored solution to find, 30-100 (depending on the plan selected) relevant job postings per search, matched to your experience!
            </p>
            
            <div className="bg-blue-50 p-6 rounded-lg">
              <p className="text-center font-bold text-lg">
                REAL privacy is our priority! No personal information is collected or stored. No account registration or password required.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="flex items-start gap-4">
              <TrendingUp className="h-6 w-6 text-blue-600 mt-1 flex-shrink-0" />
              <p className="text-lg text-gray-700">
                <span className="font-semibold">No more endless scrolling through irrelevant listings!</span>
              </p>
            </div>
            
            <div className="flex items-start gap-4">
              <FileText className="h-6 w-6 text-blue-600 mt-1 flex-shrink-0" />
              <p className="text-lg text-gray-700">
                <span className="font-semibold">Each search generates customized cover letters</span> formatted for each matched listing
              </p>
            </div>
            
            <div className="flex items-start gap-4">
              <Shield className="h-6 w-6 text-blue-600 mt-1 flex-shrink-0" />
              <p className="text-lg text-gray-700">
                Say goodbye to generic templates and hello to <span className="font-semibold">personalized pitches that stand out to employers.</span>
              </p>
            </div>
            
            <p className="text-lg text-gray-700 text-center pt-6">
              Pure, efficient job searching with a summary report that includes all you need: job descriptions, URLs, and posting dates.
            </p>
            
            <div className="text-center space-y-2 pt-4">
              <p className="text-lg font-semibold text-blue-600">#jobsearchassistant</p>
              <p className="text-lg font-semibold text-blue-600">#jobsearchassist.org</p>
              <p className="text-lg font-semibold text-blue-600">#coverlettercovered</p>
            </div>
          </div>
        </div>
      </section>

      {/* Services / CTA */}
      <section className="bg-blue-600 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Services
          </h2>
          
          <p className="text-2xl mb-8 border-2 border-white inline-block px-8 py-4 rounded">
            Tailored Support for Job Seekers
          </p>
          
          <h3 className="text-3xl md:text-4xl font-bold mb-8">
            Let jobsearchassist.org help you play the numbers game.
          </h3>
          
          {/* Job Openings Screenshot */}
          <div className="max-w-2xl mx-auto mb-12">
            <img 
              src="/job-openings-screenshot.avif" 
              alt="Job search results with customized cover letters"
              className="rounded-lg shadow-2xl border-4 border-white/20"
            />
            <p className="mt-4 text-lg">
              Quickly generate pre-formatted, customized cover letters to submit with your resume all or some of the openings generated.
            </p>
          </div>
          
          {/* Pricing Preview - Condensed */}
          <div className="max-w-4xl mx-auto mb-12">
            <h3 className="text-3xl font-bold mb-6 text-center">Choose Your Plan</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-white/10 backdrop-blur rounded-lg p-6 border-2 border-white/30">
                <h4 className="text-2xl font-bold mb-2">Expert</h4>
                <div className="text-4xl font-bold mb-4">$10</div>
                <p className="text-sm">30 job matches</p>
              </div>
              <div className="bg-white/20 backdrop-blur rounded-lg p-6 border-4 border-yellow-400 relative">
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-yellow-400 text-blue-900 px-3 py-1 rounded-full text-xs font-bold">
                  POPULAR
                </div>
                <h4 className="text-2xl font-bold mb-2">Pro</h4>
                <div className="text-4xl font-bold mb-4">$25</div>
                <p className="text-sm">75 job matches</p>
              </div>
              <div className="bg-white/10 backdrop-blur rounded-lg p-6 border-2 border-white/30">
                <h4 className="text-2xl font-bold mb-2">Superhero</h4>
                <div className="text-4xl font-bold mb-4">$40</div>
                <p className="text-sm">100 job matches</p>
              </div>
            </div>
            <p className="text-center mt-4 text-sm">All plans include AI-powered matching & personalized cover letters</p>
          </div>
          
          <Button 
            size="lg"
            onClick={() => setLocation('/app')}
            className="bg-green-500 hover:bg-green-600 text-white text-xl px-12 py-6 rounded-full font-bold shadow-lg"
          >
            Let's Get Started!
          </Button>
          
          <p className="mt-8 text-xl italic text-yellow-300">
            Make smarter moves, save time, and boost your chances in the numbers game with each search.
          </p>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold text-blue-700 mb-12 text-center">
            How It Works
          </h2>
          
          <div className="max-w-4xl mx-auto space-y-8">
            <div className="flex items-start gap-6">
              <div className="flex-shrink-0 w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-xl font-bold">
                1
              </div>
              <div>
                <h3 className="text-2xl font-bold text-blue-600 mb-2">Choose Your Plan</h3>
                <p className="text-gray-700 leading-relaxed">
                  Select from Expert ($10), Pro ($25), or Superhero ($40-50) tiers based on how many job matches you need (30, 60, or 100 results).
                </p>
              </div>
            </div>

            <div className="flex items-start gap-6">
              <div className="flex-shrink-0 w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-xl font-bold">
                2
              </div>
              <div>
                <h3 className="text-2xl font-bold text-blue-600 mb-2">Fill Out Your Search</h3>
                <p className="text-gray-700 leading-relaxed">
                  Enter your desired job title, location, keywords, and upload your resume. Optionally add company-specific search for an extra $2.50.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-6">
              <div className="flex-shrink-0 w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-xl font-bold">
                3
              </div>
              <div>
                <h3 className="text-2xl font-bold text-blue-600 mb-2">Complete Payment</h3>
                <p className="text-gray-700 leading-relaxed">
                  Secure checkout via Stripe. Your search begins immediately after payment confirmation.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-6">
              <div className="flex-shrink-0 w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-xl font-bold">
                4
              </div>
              <div>
                <h3 className="text-2xl font-bold text-blue-600 mb-2">Get Your Results</h3>
                <p className="text-gray-700 leading-relaxed">
                  AI analyzes job listings and matches them to your resume and keywords. Select which positions you want to pursue.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-6">
              <div className="flex-shrink-0 w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-xl font-bold">
                5
              </div>
              <div>
                <h3 className="text-2xl font-bold text-blue-600 mb-2">Apply with Confidence</h3>
                <p className="text-gray-700 leading-relaxed">
                  Download personalized cover letters for each selected position, plus a summary report with all job details, URLs, and posting dates.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold text-blue-700 mb-12 text-center">
            Pricing
          </h2>
          
          <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-8">
            {/* Expert Tier */}
            <div className="bg-white rounded-lg shadow-lg p-8 border-2 border-gray-200">
              <h3 className="text-3xl font-bold text-blue-600 mb-4 text-center">Expert</h3>
              <div className="text-center mb-6">
                <span className="text-5xl font-bold text-gray-900">$10</span>
              </div>
              <ul className="space-y-4 mb-8">
                <li className="flex items-start gap-3">
                  <svg className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-700">Up to 30 job matches</span>
                </li>
                <li className="flex items-start gap-3">
                  <svg className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-700">3 AI-generated keywords</span>
                </li>
                <li className="flex items-start gap-3">
                  <svg className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-700">Basic resume check</span>
                </li>
                <li className="flex items-start gap-3">
                  <svg className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-700">Personalized cover letters</span>
                </li>
              </ul>
            </div>

            {/* Pro Tier */}
            <div className="bg-white rounded-lg shadow-xl p-8 border-4 border-blue-600 relative">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white px-4 py-1 rounded-full text-sm font-bold">
                POPULAR
              </div>
              <h3 className="text-3xl font-bold text-blue-600 mb-4 text-center">Pro</h3>
              <div className="text-center mb-6">
                <span className="text-5xl font-bold text-gray-900">$25</span>
              </div>
              <ul className="space-y-4 mb-8">
                <li className="flex items-start gap-3">
                  <svg className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-700">Up to 60 job matches</span>
                </li>
                <li className="flex items-start gap-3">
                  <svg className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-700">5 AI-generated keywords</span>
                </li>
                <li className="flex items-start gap-3">
                  <svg className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-700">Enhanced resume check</span>
                </li>
                <li className="flex items-start gap-3">
                  <svg className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-700">Personalized cover letters</span>
                </li>
              </ul>
            </div>

            {/* Superhero Tier */}
            <div className="bg-white rounded-lg shadow-lg p-8 border-2 border-gray-200">
              <h3 className="text-3xl font-bold text-blue-600 mb-4 text-center">Superhero</h3>
              <div className="text-center mb-6">
                <span className="text-5xl font-bold text-gray-900">$40</span>
              </div>
              <ul className="space-y-4 mb-8">
                <li className="flex items-start gap-3">
                  <svg className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-700">Up to 100 job matches</span>
                </li>
                <li className="flex items-start gap-3">
                  <svg className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-700">7 AI-generated keywords</span>
                </li>
                <li className="flex items-start gap-3">
                  <svg className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-700">Premium resume check</span>
                </li>
                <li className="flex items-start gap-3">
                  <svg className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-700">Personalized cover letters</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="text-center mt-12">
            <p className="text-xl text-gray-700 mb-4">
              <span className="font-bold">Add-on:</span> Company-Specific Search for +$2.50
            </p>
            <Button 
              size="lg"
              onClick={() => setLocation('/app')}
              className="bg-blue-600 hover:bg-blue-700 text-white text-xl px-12 py-6 rounded-full font-bold shadow-lg"
            >
              Get Started Now
            </Button>
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section id="statistics" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold text-blue-700 mb-12 text-center">
            Labor Market Statistics
          </h2>
          
          <div className="max-w-4xl mx-auto space-y-8">
            <p className="text-xl text-gray-700 leading-relaxed text-center mb-8">
              Understanding the current job market helps you make informed decisions. Here are key statistics from the U.S. Department of Labor:
            </p>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-blue-50 rounded-lg p-6 border-2 border-blue-200">
                <h3 className="text-2xl font-bold text-blue-600 mb-4">Employment Data</h3>
                <p className="text-gray-700 mb-4">
                  The Bureau of Labor Statistics tracks employment trends, job openings, and labor market conditions across all industries and regions.
                </p>
                <a 
                  href="https://www.bls.gov/news.release/empsit.toc.htm" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:text-blue-800 font-semibold underline"
                >
                  View Employment Situation Summary →
                </a>
              </div>

              <div className="bg-blue-50 rounded-lg p-6 border-2 border-blue-200">
                <h3 className="text-2xl font-bold text-blue-600 mb-4">Job Openings</h3>
                <p className="text-gray-700 mb-4">
                  JOLTS (Job Openings and Labor Turnover Survey) provides data on job vacancies, hires, and separations to help you understand market demand.
                </p>
                <a 
                  href="https://www.bls.gov/news.release/jolts.toc.htm" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:text-blue-800 font-semibold underline"
                >
                  View JOLTS Report →
                </a>
              </div>

              <div className="bg-blue-50 rounded-lg p-6 border-2 border-blue-200">
                <h3 className="text-2xl font-bold text-blue-600 mb-4">Unemployment Rates</h3>
                <p className="text-gray-700 mb-4">
                  Track national and regional unemployment rates to understand competition levels in your target job market and location.
                </p>
                <a 
                  href="https://www.bls.gov/news.release/laus.toc.htm" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:text-blue-800 font-semibold underline"
                >
                  View Regional Unemployment Data →
                </a>
              </div>

              <div className="bg-blue-50 rounded-lg p-6 border-2 border-blue-200">
                <h3 className="text-2xl font-bold text-blue-600 mb-4">Occupational Outlook</h3>
                <p className="text-gray-700 mb-4">
                  Research career paths, salary expectations, and growth projections for hundreds of occupations to plan your job search strategy.
                </p>
                <a 
                  href="https://www.bls.gov/ooh/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:text-blue-800 font-semibold underline"
                >
                  View Occupational Outlook Handbook →
                </a>
              </div>
            </div>

            <div className="text-center mt-12 p-6 bg-gray-50 rounded-lg">
              <p className="text-lg text-gray-700">
                <span className="font-bold">Why it matters:</span> Job searching is a numbers game. The more relevant applications you submit with quality cover letters, the better your chances of landing interviews. Our service helps you maximize your reach efficiently.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold text-blue-700 mb-12 text-center">
            Frequently Asked Questions
          </h2>
          
          <div className="max-w-4xl mx-auto space-y-8">
            {/* FAQ 1 */}
            <div className="border-b border-gray-200 pb-6">
              <h3 className="text-2xl font-bold text-blue-600 mb-3">What is JobSearchAssist?</h3>
              <p className="text-gray-700 leading-relaxed">
                jobsearchassist.org is a browser-based application which uses your uploaded resume and keywords to search open Google Jobs listings, find job openings relevant to your resume and key words, and provide you with a list of matches. Once you decide which matches you want to proceed with, jobsearchassist.org will generate job-posting specific, pre-formatted cover letters for each posting; and a summary file containing the details of each posting (Company, Title, Office Location City, Work Style, (Remote, Hybrid, In-Office) job posting URL, and posting date. This allows you to go straight to the matched job posting and begin the online application process.
              </p>
            </div>

            {/* FAQ 2 */}
            <div className="border-b border-gray-200 pb-6">
              <h3 className="text-2xl font-bold text-blue-600 mb-3">How does it generate cover letters?</h3>
              <p className="text-gray-700 leading-relaxed">
                It uses the hiring entities information in the job description, your resume and the job description to compose a pre-formatted, customized cover letter to submit with your application.
              </p>
            </div>

            {/* FAQ 3 */}
            <div className="border-b border-gray-200 pb-6">
              <h3 className="text-2xl font-bold text-blue-600 mb-3">Is my data safe?</h3>
              <ul className="text-gray-700 leading-relaxed space-y-2 list-disc list-inside">
                <li>No account creation or password needed</li>
                <li>Uploaded documents are not stored</li>
                <li>Search results are not stored</li>
              </ul>
            </div>

            {/* FAQ 4 */}
            <div className="border-b border-gray-200 pb-6">
              <h3 className="text-2xl font-bold text-blue-600 mb-3">What is the fee to run a single search?</h3>
              <p className="text-gray-700 leading-relaxed">
                The fee for a single search (50-100 listings) is $30 USD. <span className="font-semibold text-green-600">Early adopter discount (first year of operations) is -$5.</span>
              </p>
            </div>

            {/* FAQ 5 */}
            <div className="border-b border-gray-200 pb-6">
              <h3 className="text-2xl font-bold text-blue-600 mb-3">What jobsearchassist.org is NOT</h3>
              <ul className="text-gray-700 leading-relaxed space-y-2 list-disc list-inside">
                <li>Responsible for the key words you enter for job matching. Choose carefully, as your key words determine the quality of your job listing matches</li>
                <li>A replacement for your own review of the job listings and the cover letters to ensure they accurately describe your experience</li>
                <li>A guarantee you will get a response to your application, an interview, or a job</li>
                <li>A resume writing or resume review or counseling service - it uses the resume you upload (we may post general resume tips and tricks at a later date)</li>
                <li>An automated job application service - you must apply manually on the company website with your resume and cover letter (we may include this feature in a future release)</li>
              </ul>
            </div>

            {/* FAQ 6 */}
            <div className="border-b border-gray-200 pb-6">
              <h3 className="text-2xl font-bold text-blue-600 mb-3">Is there a refund policy?</h3>
              <p className="text-gray-700 leading-relaxed">
                All sales are final. Refunds for non-performance will be processed by jobsearchassist.org automatically on a monthly basis. Any inquiries regarding refund status MUST include the transaction ID provided to you by the app.
              </p>
            </div>

            {/* FAQ 7 */}
            <div className="border-b border-gray-200 pb-6">
              <h3 className="text-2xl font-bold text-blue-600 mb-3">What are the payment options?</h3>
              <p className="text-gray-700 leading-relaxed">
                We process payments through Stripe. Payment options are available through Stripe.
              </p>
            </div>

            {/* FAQ 8 */}
            <div className="border-b border-gray-200 pb-6">
              <h3 className="text-2xl font-bold text-blue-600 mb-3">What browsers are supported?</h3>
              <p className="text-gray-700 leading-relaxed">
                It works on all modern web browsers.
              </p>
            </div>

            {/* FAQ 9 */}
            <div className="border-b border-gray-200 pb-6">
              <h3 className="text-2xl font-bold text-blue-600 mb-3">How can I contact jobsearchassist.org?</h3>
              <p className="text-gray-700 leading-relaxed">
                Our email is <a href="mailto:principal@jobsearchassist.org" className="text-blue-600 hover:underline font-semibold">principal@jobsearchassist.org</a>. Please note we cannot respond to inquiries about specific transactions. Non-performance (files not generated, generated files are blank, unrecoverable search interruptions due to network glitches, etc.) will be flagged on the backend and refunds issued via the same method used for payment. If you do email us, please include the CustomerID reference shown on your payment record. It will look like this: JSA-YYYY-XXXXXX.
              </p>
            </div>


          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-100 py-8">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-2xl font-bold text-blue-700 mb-4">CONTACT</h3>
          <a 
            href="mailto:principal@jobsearchassist.org" 
            className="text-lg text-blue-600 hover:underline"
          >
            principal@jobsearchassist.org
          </a>
          <p className="mt-4 text-gray-600">© 2025. All rights reserved.</p>
          <p className="mt-2 text-sm text-gray-500">
            🔒 Your Privacy is Protected - No personal information is stored. All data is deleted after download.
          </p>
        </div>
      </footer>
    </div>
  );
}

