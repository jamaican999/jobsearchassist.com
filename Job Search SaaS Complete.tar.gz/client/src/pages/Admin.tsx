import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, CheckCircle2, DollarSign, TrendingUp, RefreshCw } from "lucide-react";
import { toast } from "sonner";

export default function Admin() {
  const { data: stats, refetch: refetchStats } = trpc.admin.getDashboardStats.useQuery();
  const { data: recentSearches, refetch: refetchSearches } = trpc.admin.getRecentSearches.useQuery();
  
  const processRefundsMutation = trpc.admin.processRefunds.useMutation({
    onSuccess: (result) => {
      toast.success(`Processed ${result.processed} refunds totaling $${result.totalAmount / 100}`);
      refetchStats();
      refetchSearches();
    },
    onError: () => {
      toast.error('Failed to process refunds');
    },
  });

  if (!stats) {
    return <div className="p-8">Loading...</div>;
  }

  const failedSearches = recentSearches?.filter(s => s.status === 'failed') || [];
  const refundedSearches = recentSearches?.filter(s => s.status === 'refunded') || [];

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-4xl font-bold" style={{ color: '#0066CC' }}>
            Admin Dashboard
          </h1>
          <p className="text-gray-600 mt-2">
            Monitor searches, revenue, and refunds
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                Total Searches
              </CardTitle>
              <TrendingUp className="h-4 w-4 text-gray-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats.totalSearches}</div>
              <p className="text-xs text-gray-600 mt-1">
                {stats.completedSearches} completed
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                Total Revenue
              </CardTitle>
              <DollarSign className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">
                ${(stats.totalRevenue / 100).toFixed(2)}
              </div>
              <p className="text-xs text-gray-600 mt-1">
                ${((stats.totalRevenue - stats.totalRefunded) / 100).toFixed(2)} net
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                Failed Searches
              </CardTitle>
              <AlertCircle className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-red-600">
                {stats.failedSearches}
              </div>
              <p className="text-xs text-gray-600 mt-1">
                {stats.flaggedForRefund} pending refund
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                Refunds Issued
              </CardTitle>
              <RefreshCw className="h-4 w-4 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-600">
                ${(stats.totalRefunded / 100).toFixed(2)}
              </div>
              <p className="text-xs text-gray-600 mt-1">
                {stats.refundedSearches} searches
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Process Refunds Button */}
        {stats.flaggedForRefund > 0 && (
          <Card className="bg-red-50 border-red-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-red-900">
                    {stats.flaggedForRefund} searches pending refund
                  </h3>
                  <p className="text-sm text-red-700 mt-1">
                    Click to process all pending refunds via Stripe
                  </p>
                </div>
                <Button
                  onClick={() => processRefundsMutation.mutate()}
                  disabled={processRefundsMutation.isPending}
                  style={{ backgroundColor: '#0066CC' }}
                  className="text-white"
                >
                  {processRefundsMutation.isPending ? 'Processing...' : 'Process Refunds'}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Failed Searches Table */}
        {failedSearches.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-red-600" />
                Failed Searches
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2 text-sm font-semibold">Customer ID</th>
                      <th className="text-left p-2 text-sm font-semibold">Date</th>
                      <th className="text-left p-2 text-sm font-semibold">Keywords</th>
                      <th className="text-left p-2 text-sm font-semibold">Error</th>
                      <th className="text-left p-2 text-sm font-semibold">Amount</th>
                      <th className="text-left p-2 text-sm font-semibold">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {failedSearches.map((search) => (
                      <tr key={search.id} className="border-b hover:bg-gray-50">
                        <td className="p-2 font-mono text-sm">{search.customerId}</td>
                        <td className="p-2 text-sm">
                          {new Date(search.createdAt).toLocaleDateString()}
                        </td>
                        <td className="p-2 text-sm">{search.searchKeywords}</td>
                        <td className="p-2 text-sm text-red-600 max-w-xs truncate">
                          {search.errorMessage}
                        </td>
                        <td className="p-2 text-sm font-semibold">
                          ${(search.revenue / 100).toFixed(2)}
                        </td>
                        <td className="p-2">
                          {search.flaggedForRefund ? (
                            <span className="text-xs bg-orange-100 text-orange-800 px-2 py-1 rounded">
                              Pending Refund
                            </span>
                          ) : (
                            <span className="text-xs bg-red-100 text-red-800 px-2 py-1 rounded">
                              Failed
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Recent Refunds Table */}
        {refundedSearches.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-green-600" />
                Recent Refunds
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2 text-sm font-semibold">Customer ID</th>
                      <th className="text-left p-2 text-sm font-semibold">Date</th>
                      <th className="text-left p-2 text-sm font-semibold">Refunded</th>
                      <th className="text-left p-2 text-sm font-semibold">Amount</th>
                      <th className="text-left p-2 text-sm font-semibold">Reason</th>
                    </tr>
                  </thead>
                  <tbody>
                    {refundedSearches.map((search) => (
                      <tr key={search.id} className="border-b hover:bg-gray-50">
                        <td className="p-2 font-mono text-sm">{search.customerId}</td>
                        <td className="p-2 text-sm">
                          {new Date(search.createdAt).toLocaleDateString()}
                        </td>
                        <td className="p-2 text-sm">
                          {search.refundProcessedAt 
                            ? new Date(search.refundProcessedAt).toLocaleDateString()
                            : '-'}
                        </td>
                        <td className="p-2 text-sm font-semibold text-green-600">
                          ${((search.refundAmount || 0) / 100).toFixed(2)}
                        </td>
                        <td className="p-2 text-sm text-gray-600 max-w-xs truncate">
                          {search.errorMessage}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

