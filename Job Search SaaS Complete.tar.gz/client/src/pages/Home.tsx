import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Loader2, Search, FileText, Download, Briefcase, MapPin, Calendar, ExternalLink, CheckCircle2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import PricingTierCard from "@/components/PricingTierCard";
import OrderSummary from "@/components/OrderSummary";
import LoadingSpinner from "@/components/LoadingSpinner";
import { useAuth } from "@/_core/hooks/useAuth";

interface Job {
  jobId: string;
  title: string;
  company: string;
  location: string;
  description: string;
  workStyle: 'Remote' | 'Hybrid' | 'In-Office';
  postingDate: string;
  jobUrl: string;
  keywordMatches: string[];
  matchCount: number;
}

export default function Home() {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';
  
  const [step, setStep] = useState<'search' | 'results' | 'generate' | 'download'>('search');
  
  // Search form state
  const [searchKeywords, setSearchKeywords] = useState("");
  const [filterKeywords, setFilterKeywords] = useState("");
  const [location, setLocation] = useState("");
  const [datePosted, setDatePosted] = useState<string>("");
  const [minMatches, setMinMatches] = useState("2");
  
  // Batch 2 state
  const [enableBatch2, setEnableBatch2] = useState(false);
  const [searchKeywords2, setSearchKeywords2] = useState("");
  const [filterKeywords2, setFilterKeywords2] = useState("");
  
  // Resume state
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [resumeText, setResumeText] = useState("");
  const [resumeId, setResumeId] = useState("");
  
  // Results state
  const [searchId, setSearchId] = useState("");
  const [customerId, setCustomerId] = useState("");
  const [jobs, setJobs] = useState<Job[]>([]);
  const [selectedJobs, setSelectedJobs] = useState<Set<string>>(new Set());
  const [totalFound, setTotalFound] = useState(0);
  
  // Download state
  const [downloadFiles, setDownloadFiles] = useState<Array<{ name: string; url: string }>>([]);
  
  // Payment state
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  
  // Pricing state
  const [selectedTier, setSelectedTier] = useState<'expert' | 'pro' | 'superhero'>('pro');
  const [companySearch, setCompanySearch] = useState(false);
  const [companyName, setCompanyName] = useState("");
  
  const tierPrices = {
    expert: 10,
    pro: 25,
    superhero: 40,
  };
  const companySearchPrice = 2.50;
  const totalPrice = tierPrices[selectedTier] + (companySearch ? companySearchPrice : 0);
  
  // Failed search state
  const [failedSearchId, setFailedSearchId] = useState<string | null>(null);
  const [searchFailed, setSearchFailed] = useState(false);
  const [sessionId, setSessionId] = useState<string>(() => {
    // Generate or retrieve session ID
    let sid = sessionStorage.getItem('sessionId');
    if (!sid) {
      sid = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      sessionStorage.setItem('sessionId', sid);
    }
    return sid;
  });
  
  // Mutations
  const searchMutation = trpc.jobs.search.useMutation();
  const uploadMutation = trpc.jobs.uploadResume.useMutation();
  const generateMutation = trpc.jobs.generateCoverLetters.useMutation();
  const createCheckoutMutation = trpc.payment.createCheckoutSession.useMutation();
  const retryMutation = trpc.jobs.retrySearch.useMutation();
  const verifyPaymentQuery = trpc.payment.verifyPayment.useQuery(
    { sessionId: new URLSearchParams(window.location.search).get('session_id') || '' },
    { enabled: false }
  );
  
  const handleResumeUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (file.type !== 'application/pdf') {
      toast.error('Please upload a PDF file');
      return;
    }
    
    setResumeFile(file);
    
    // Convert to base64
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result?.toString().split(',')[1];
      if (!base64) return;
      
      try {
        const result = await uploadMutation.mutateAsync({
          fileData: base64,
          fileName: file.name,
        });
        
        setResumeText(result.resumeText);
        setResumeId(result.resumeId);
        toast.success('Resume uploaded successfully');
      } catch (error) {
        toast.error('Failed to upload resume');
      }
    };
    reader.readAsDataURL(file);
  };
  
  // Check for payment success on page load
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const paymentStatus = urlParams.get('payment');
    const sessionId = urlParams.get('session_id');
    const searchIdParam = urlParams.get('search_id');
    
    if (paymentStatus === 'success' && sessionId && searchIdParam) {
      // Payment successful, run the search
      handleSearchAfterPayment(searchIdParam);
      // Clean up URL
      window.history.replaceState({}, '', '/app');
    } else if (paymentStatus === 'cancelled') {
      toast.error('Payment was cancelled');
      // Clean up URL
      window.history.replaceState({}, '', '/app');
    }
  }, []);
  
  const handleSearchAfterPayment = async (searchIdParam: string) => {
    // Retrieve search params from sessionStorage
    const savedParams = sessionStorage.getItem('pendingSearch');
    if (!savedParams) {
      toast.error('Search parameters not found');
      return;
    }
    
    const params = JSON.parse(savedParams);
    sessionStorage.removeItem('pendingSearch');
    
    try {
      const result = await searchMutation.mutateAsync(params);
      
      setSearchId(result.searchId);
      setCustomerId(result.customerId);
      setJobs(result.jobs);
      setTotalFound(result.totalFound);
      setStep('results');
      setSearchFailed(false);
      setFailedSearchId(null);
      toast.success(`Found ${result.jobs.length} matching jobs!`);
    } catch (error) {
      setSearchFailed(true);
      setFailedSearchId(searchIdParam);
      toast.error('Search failed. Your payment has been automatically refunded. You can retry below.');
    }
  };
  
  const handleSearch = async () => {
    if (!searchKeywords.trim() || !filterKeywords.trim()) {
      toast.error('Please enter Batch 1 search and filter keywords');
      return;
    }
    
    if (enableBatch2 && (!searchKeywords2.trim() || !filterKeywords2.trim())) {
      toast.error('Please enter Batch 2 keywords or disable Batch 2');
      return;
    }
    
    if (!resumeFile) {
      toast.error('Please upload your resume first');
      return;
    }
    
    // Prepare search parameters
    const searchParams = {
      searchKeywords: searchKeywords.split(',').map(k => k.trim()).filter(Boolean),
      filterKeywords: filterKeywords.split(',').map(k => k.trim()).filter(Boolean),
      location: location || undefined,
      datePosted: datePosted as any || undefined,
      minKeywordMatches: parseInt(minMatches) || 2,
      fuzzyThreshold: 65,
      enableBatch2,
      searchKeywords2: enableBatch2 ? searchKeywords2.split(',').map(k => k.trim()).filter(Boolean) : undefined,
      filterKeywords2: enableBatch2 ? filterKeywords2.split(',').map(k => k.trim()).filter(Boolean) : undefined,
    };
    
    // Save params for after payment
    sessionStorage.setItem('pendingSearch', JSON.stringify(searchParams));
    
    // Generate IDs
    const tempSearchId = `search_${Date.now()}`;
    const tempCustomerId = `JSA-${new Date().getFullYear()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    
    setIsProcessingPayment(true);
    
    try {
      // Create Stripe Checkout session
      const result = await createCheckoutMutation.mutateAsync({
        customerId: tempCustomerId,
        searchId: tempSearchId,
        tier: selectedTier,
        companySearch: companySearch,
        companyName: companySearch ? companyName : undefined,
        searchParams: {
          searchKeywords: searchParams.searchKeywords,
          filterKeywords: searchParams.filterKeywords,
          location: searchParams.location,
          datePosted: searchParams.datePosted,
          minKeywordMatches: searchParams.minKeywordMatches,
          enableBatch2: searchParams.enableBatch2,
          searchKeywords2: searchParams.searchKeywords2,
          filterKeywords2: searchParams.filterKeywords2,
        },
      });
      
      // Redirect to Stripe Checkout
      if (result.url) {
        window.location.href = result.url;
      } else {
        throw new Error('No checkout URL received');
      }
    } catch (error) {
      setIsProcessingPayment(false);
      sessionStorage.removeItem('pendingSearch');
      toast.error('Failed to create payment session. Please try again.');
    }
  };
  
  // Admin bypass function - skip payment and search directly
  const handleAdminBypass = async () => {    if (!searchKeywords.trim() || !filterKeywords.trim()) {
      toast.error('Please enter Batch 1 search and filter keywords');
      return;
    }
    
    if (enableBatch2 && (!searchKeywords2.trim() || !filterKeywords2.trim())) {
      toast.error('Please enter Batch 2 keywords or disable Batch 2');
      return;
    }
    
    if (!resumeFile) {
      toast.error('Please upload your resume first');
      return;
    }
    
    toast.success('Admin bypass - running search without payment');
    
    try {
      const result = await searchMutation.mutateAsync({
        searchKeywords: searchKeywords.split(',').map(k => k.trim()).filter(Boolean),
        filterKeywords: filterKeywords.split(',').map(k => k.trim()).filter(Boolean),
        location: location || undefined,
        datePosted: datePosted as any || undefined,
        minKeywordMatches: parseInt(minMatches) || 2,
        fuzzyThreshold: 65,
        tier: selectedTier,
        companySearch: companySearch,
        companyName: companySearch ? companyName : undefined,
        enableBatch2,
        searchKeywords2: enableBatch2 ? searchKeywords2.split(',').map(k => k.trim()).filter(Boolean) : undefined,
        filterKeywords2: enableBatch2 ? filterKeywords2.split(',').map(k => k.trim()).filter(Boolean) : undefined,
      });
      
      setJobs(result.jobs);
      setStep('results');
      toast.success(`Found ${result.jobs.length} matching jobs!`);
    } catch (error) {
      console.error('Search error:', error);
      toast.error('Search failed. Please try again.');
    }
  };
  
  const toggleJobSelection = (jobId: string) => {
    const newSelected = new Set(selectedJobs);
    if (newSelected.has(jobId)) {
      newSelected.delete(jobId);
    } else {
      newSelected.add(jobId);
    }
    setSelectedJobs(newSelected);
  };
  
  const handleSelectAll = () => {
    const allJobIds = new Set(jobs.map(job => job.jobId));
    setSelectedJobs(allJobIds);
    toast.success(`Selected all ${jobs.length} jobs`);
  };
  
  const handleDeselectAll = () => {
    setSelectedJobs(new Set());
    toast.success('Deselected all jobs');
  };
  
  const handleGenerateCoverLetters = async () => {
    if (selectedJobs.size === 0) {
      toast.error('Please select at least one job');
      return;
    }
    
    setStep('generate');
    
    try {
      const selectedJobData = jobs.filter(j => selectedJobs.has(j.jobId));
      const result = await generateMutation.mutateAsync({
        searchId,
        resumeText,
        selectedJobs: selectedJobData,
      });
      
      setDownloadFiles(result.files);
      setStep('download');
      toast.success(`Generated ${result.coverLettersGenerated} cover letters!`);
    } catch (error) {
      toast.error('Failed to generate cover letters');
      setStep('results');
    }
  };
  
  const handleRetry = async () => {
    if (!failedSearchId) {
      toast.error('No failed search to retry');
      return;
    }
    
    try {
      const result = await retryMutation.mutateAsync({
        searchId: failedSearchId,
        sessionId: sessionId,
      });
      
      setSearchId(result.searchId);
      setCustomerId(result.customerId);
      setJobs(result.jobs);
      setTotalFound(result.totalFound);
      setStep('results');
      setSearchFailed(false);
      setFailedSearchId(null);
      toast.success(`Retry successful! Found ${result.jobs.length} matching jobs!`);
    } catch (error: any) {
      const errorMessage = error?.message || 'Retry failed';
      toast.error(errorMessage);
      
      // If max retries reached, disable retry button
      if (errorMessage.includes('Maximum retry attempts')) {
        setFailedSearchId(null);
      }
    }
  };
  
  return (
    <div className="min-h-screen bg-white">
      {/* Header - Matching jobsearchassist.org */}
      <header className="border-b bg-white sticky top-0 z-10 shadow-sm">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Briefcase className="h-7 w-7" style={{ color: '#0066CC' }} />
              <div>
                <h1 className="text-2xl font-bold" style={{ color: '#0066CC' }}>
                  JobSearchAssist.org
                </h1>
                <p className="text-sm text-gray-600">Play the numbers game</p>
              </div>
            </div>
            <Badge variant="secondary" className="bg-green-100 text-green-700">
              Privacy First
            </Badge>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {step === 'search' && (
          <div className="max-w-7xl mx-auto">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Main Content */}
              <div className="lg:col-span-2 space-y-8">
                {/* Hero Section */}
                <div className="text-center space-y-4 py-8">
                  <h2 className="text-4xl font-bold tracking-tight" style={{ color: '#0066CC' }}>
                    Start Your Job Search
                  </h2>
                  <p className="text-xl text-gray-600">
                    Find relevant job postings matched to your experience
                  </p>
                  <p className="text-lg text-gray-500">
                    Generate customized cover letters for each listing
                  </p>
                </div>

                {/* Company Search Add-on */}
                <Card className="border-2 border-blue-200">
                  <CardContent className="pt-6">
                    <div className="flex items-start space-x-3">
                      <Checkbox
                        id="companySearch"
                        checked={companySearch}
                        onCheckedChange={(checked) => setCompanySearch(checked as boolean)}
                        className="mt-1"
                      />
                      <div className="flex-1">
                        <Label htmlFor="companySearch" className="text-base font-semibold cursor-pointer">
                          Add Company-Specific Search (+$2.50)
                        </Label>
                        <p className="text-sm text-gray-500 mt-1">
                          Search for jobs at a specific company (e.g., Google, Amazon, Microsoft)
                        </p>
                        {companySearch && (
                          <Input
                            placeholder="Enter company name"
                            value={companyName}
                            onChange={(e) => setCompanyName(e.target.value)}
                            className="mt-3"
                          />
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>

            {/* Instructions */}
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="pt-6 pb-6">
                <h3 className="font-semibold text-lg mb-3" style={{ color: '#0066CC' }}>📋 How It Works</h3>
                <ol className="space-y-2 text-sm text-gray-700">
                  <li className="flex gap-2">
                    <span className="font-semibold">1.</span>
                    <span><strong>Upload your resume</strong> - We'll analyze your experience and skills</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-semibold">2.</span>
                    <span><strong>Enter search keywords</strong> - Job titles or roles you're looking for (comma-separated)</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-semibold">3.</span>
                    <span><strong>Add required skills</strong> - Must-have keywords to filter results (comma-separated)</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-semibold">4.</span>
                    <span><strong>Click "Search Jobs - $25"</strong> - You'll be redirected to secure payment, then we'll find 50-100 matching jobs</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-semibold">5.</span>
                    <span><strong>Select jobs & generate cover letters</strong> - We'll create personalized cover letters for each job you select</span>
                  </li>
                </ol>
              </CardContent>
            </Card>

            {/* Search Form */}
            <Card className="shadow-lg">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-white">
                <CardTitle style={{ color: '#0066CC' }}>Configure Your Search</CardTitle>
                <CardDescription>
                  Upload your resume and tell us what you're looking for
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                {/* Condensed Pricing Selection */}
                <div className="space-y-3">
                  <Label className="text-base font-semibold">Select Your Plan</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedTier('expert')}
                      className={`p-3 rounded-lg border-2 transition-all ${
                        selectedTier === 'expert'
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-blue-300'
                      }`}
                    >
                      <div className="text-center">
                        <div className="font-bold text-lg" style={{ color: '#0066CC' }}>$10</div>
                        <div className="text-xs font-semibold">Expert</div>
                        <div className="text-xs text-gray-500 mt-1">30 jobs</div>
                      </div>
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedTier('pro')}
                      className={`p-3 rounded-lg border-2 transition-all relative ${
                        selectedTier === 'pro'
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-blue-300'
                      }`}
                    >
                      <Badge className="absolute -top-2 left-1/2 -translate-x-1/2 bg-green-500 text-white text-xs px-2 py-0">Popular</Badge>
                      <div className="text-center">
                        <div className="font-bold text-lg" style={{ color: '#0066CC' }}>$25</div>
                        <div className="text-xs font-semibold">Pro</div>
                        <div className="text-xs text-gray-500 mt-1">75 jobs</div>
                      </div>
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedTier('superhero')}
                      className={`p-3 rounded-lg border-2 transition-all ${
                        selectedTier === 'superhero'
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-blue-300'
                      }`}
                    >
                      <div className="text-center">
                        <div className="font-bold text-lg" style={{ color: '#0066CC' }}>$40</div>
                        <div className="text-xs font-semibold">Superhero</div>
                        <div className="text-xs text-gray-500 mt-1">100 jobs</div>
                      </div>
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 text-center">
                    All plans include AI-powered job matching and personalized cover letters
                  </p>
                </div>

                {/* Testimonials Section */}
                <div className="bg-blue-50 rounded-lg p-4 space-y-3">
                  <h4 className="text-sm font-semibold text-center" style={{ color: '#0066CC' }}>What Our Users Say</h4>
                  <div className="space-y-3">
                    {/* Testimonial 1 */}
                    <div className="bg-white rounded-md p-3 shadow-sm">
                      <div className="flex items-start gap-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <div className="flex text-yellow-400 text-xs">
                              {'★'.repeat(5)}
                            </div>
                          </div>
                          <p className="text-xs text-gray-700 italic">
                            "Landed 3 interviews in my first week! The AI-generated cover letters were spot-on and saved me hours."
                          </p>
                          <p className="text-xs text-gray-500 mt-1 font-medium">— Sarah M., Software Engineer</p>
                        </div>
                      </div>
                    </div>

                    {/* Testimonial 2 */}
                    <div className="bg-white rounded-md p-3 shadow-sm">
                      <div className="flex items-start gap-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <div className="flex text-yellow-400 text-xs">
                              {'★'.repeat(5)}
                            </div>
                          </div>
                          <p className="text-xs text-gray-700 italic">
                            "The Pro plan was worth every penny. Found 75 relevant jobs and got personalized cover letters for each. Game changer!"
                          </p>
                          <p className="text-xs text-gray-500 mt-1 font-medium">— Michael T., Marketing Manager</p>
                        </div>
                      </div>
                    </div>

                    {/* Testimonial 3 */}
                    <div className="bg-white rounded-md p-3 shadow-sm">
                      <div className="flex items-start gap-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <div className="flex text-yellow-400 text-xs">
                              {'★'.repeat(5)}
                            </div>
                          </div>
                          <p className="text-xs text-gray-700 italic">
                            "Finally, a job search tool that actually works! The keyword matching is incredibly accurate. Highly recommend."
                          </p>
                          <p className="text-xs text-gray-500 mt-1 font-medium">— Jennifer L., Data Analyst</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="border-t" />

                {/* Resume Upload */}
                <div className="space-y-2">
                  <Label htmlFor="resume" className="text-base font-semibold">
                    1. Upload Your Resume (PDF)
                  </Label>
                  <Input
                    id="resume"
                    type="file"
                    accept=".pdf"
                    onChange={handleResumeUpload}
                    disabled={uploadMutation.isPending}
                    className="cursor-pointer"
                  />
                  {resumeFile && (
                    <div className="flex items-center gap-2 text-sm text-green-600">
                      <CheckCircle2 className="h-4 w-4" />
                      {resumeFile.name} uploaded successfully
                    </div>
                  )}
                  {uploadMutation.isPending && (
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Processing resume...
                    </div>
                  )}
                </div>

                <div className="border-t pt-6" />

                {/* Batch 1 Header */}
                <div className="space-y-1">
                  <h3 className="text-lg font-semibold text-[#0066CC]">Batch 1 (Required)</h3>
                  <p className="text-sm text-gray-500">Primary job search criteria</p>
                </div>

                {/* Search Keywords */}
                <div className="space-y-2">
                  <Label htmlFor="search" className="text-base font-semibold">
                    2. Search Keywords
                  </Label>
                  <Input
                    id="search"
                    placeholder="e.g., sales operations, CRM, analytics"
                    value={searchKeywords}
                    onChange={(e) => setSearchKeywords(e.target.value)}
                    className="text-base"
                  />
                  <p className="text-sm text-gray-500">
                    Comma-separated job titles or roles you're searching for
                  </p>
                </div>

                {/* Filter Keywords */}
                <div className="space-y-2">
                  <Label htmlFor="filter" className="text-base font-semibold">
                    3. Required Skills/Keywords
                  </Label>
                  <Input
                    id="filter"
                    placeholder="e.g., Salesforce, HubSpot, SQL, Excel, Python"
                    value={filterKeywords}
                    onChange={(e) => setFilterKeywords(e.target.value)}
                    className="text-base"
                  />
                  <p className="text-sm text-gray-500">
                    Jobs must match at least {minMatches} of these keywords
                  </p>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  {/* Location */}
                  <div className="space-y-2">
                    <Label htmlFor="location">Location (Optional)</Label>
                    <Input
                      id="location"
                      placeholder="e.g., San Francisco, CA"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                    />
                  </div>

                  {/* Date Posted */}
                  <div className="space-y-2">
                    <Label htmlFor="date">Date Posted</Label>
                    <Select value={datePosted} onValueChange={setDatePosted}>
                      <SelectTrigger>
                        <SelectValue placeholder="Any time" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="any">Any time</SelectItem>
                        <SelectItem value="today">Today</SelectItem>
                        <SelectItem value="3days">Last 3 days</SelectItem>
                        <SelectItem value="week">Last week</SelectItem>
                        <SelectItem value="month">Last month</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Min Keyword Matches */}
                <div className="space-y-2">
                  <Label htmlFor="minMatches">Minimum Keyword Matches</Label>
                  <Input
                    id="minMatches"
                    type="number"
                    min="1"
                    max="10"
                    value={minMatches}
                    onChange={(e) => setMinMatches(e.target.value)}
                    className="w-32"
                  />
                  <p className="text-sm text-gray-500">
                    Higher number = more relevant but fewer results
                  </p>
                </div>

                <div className="border-t pt-6" />

                {/* Batch 2 Toggle */}
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="enableBatch2" 
                    checked={enableBatch2}
                    onCheckedChange={(checked) => setEnableBatch2(checked as boolean)}
                  />
                  <Label htmlFor="enableBatch2" className="text-base font-semibold cursor-pointer">
                    Add Batch 2 (Optional)
                  </Label>
                </div>
                <p className="text-sm text-gray-500 -mt-2">
                  Run a second search with different keywords to find more opportunities
                </p>

                {/* Batch 2 Fields */}
                {enableBatch2 && (
                  <>
                    <div className="border-t pt-6" />
                    
                    <div className="space-y-1">
                      <h3 className="text-lg font-semibold text-[#0066CC]">Batch 2 (Optional)</h3>
                      <p className="text-sm text-gray-500">Alternative job search criteria</p>
                    </div>

                    {/* Batch 2 Search Keywords */}
                    <div className="space-y-2">
                      <Label htmlFor="search2" className="text-base font-semibold">
                        Search Keywords (Batch 2)
                      </Label>
                      <Input
                        id="search2"
                        placeholder="e.g., revenue operations, business analyst"
                        value={searchKeywords2}
                        onChange={(e) => setSearchKeywords2(e.target.value)}
                        className="text-base"
                      />
                      <p className="text-sm text-gray-500">
                        Different job titles or roles to search for
                      </p>
                    </div>

                    {/* Batch 2 Filter Keywords */}
                    <div className="space-y-2">
                      <Label htmlFor="filter2" className="text-base font-semibold">
                        Required Skills/Keywords (Batch 2)
                      </Label>
                      <Input
                        id="filter2"
                        placeholder="e.g., HubSpot, Tableau, Power BI"
                        value={filterKeywords2}
                        onChange={(e) => setFilterKeywords2(e.target.value)}
                        className="text-base"
                      />
                      <p className="text-sm text-gray-500">
                        Skills to match for Batch 2 jobs
                      </p>
                    </div>
                  </>
                )}

                <div className="border-t pt-6" />

                {/* Admin Bypass Button (only visible to admin) */}
                {isAdmin && (
                  <Button
                    onClick={handleAdminBypass}
                    disabled={searchMutation.isPending || !resumeFile}
                    className="w-full text-lg py-6 mb-4"
                    size="lg"
                    variant="outline"
                    style={{ borderColor: '#FF6B00', color: '#FF6B00' }}
                  >
                    {searchMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Searching Jobs...
                      </>
                    ) : (
                      <>
                        <Search className="mr-2 h-5 w-5" />
                        Skip Payment (Admin Only)
                      </>
                    )}
                  </Button>
                )}

                <Button
                  onClick={handleSearch}
                  disabled={searchMutation.isPending || !resumeFile || isProcessingPayment}
                  className="w-full text-lg py-6"
                  size="lg"
                  style={{ backgroundColor: '#00CC66', color: 'white' }}
                >
                  {isProcessingPayment ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Redirecting to payment...
                    </>
                  ) : searchMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Searching Jobs...
                    </>
                  ) : (
                    <>
                      <Search className="mr-2 h-5 w-5" />
                      Continue to Payment - ${totalPrice.toFixed(2)}
                    </>
                  )}
                </Button>
                
                {/* Cancel Button */}
                <Button
                  onClick={() => {
                    // Reset form state
                    setSearchKeywords("");
                    setFilterKeywords("");
                    setLocation("");
                    setDatePosted("");
                    setMinMatches("2");
                    setEnableBatch2(false);
                    setSearchKeywords2("");
                    setFilterKeywords2("");
                    setResumeFile(null);
                    setResumeText("");
                    setResumeId("");
                    setSelectedTier('pro');
                    setCompanySearch(false);
                    setCompanyName("");
                    sessionStorage.removeItem('pendingSearch');
                    toast.success('Form reset successfully');
                  }}
                  variant="outline"
                  className="w-full text-lg py-6 mt-4"
                  size="lg"
                  disabled={isProcessingPayment || searchMutation.isPending}
                >
                  Cancel & Reset Form
                </Button>
                
                {/* Retry Button - Only visible for failed searches */}
                {searchFailed && failedSearchId && (
                  <Button
                    onClick={handleRetry}
                    disabled={retryMutation.isPending}
                    className="w-full text-lg py-6 mt-4"
                    size="lg"
                    style={{ backgroundColor: '#FF6B00', color: 'white' }}
                  >
                    {retryMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Retrying Search...
                      </>
                    ) : (
                      <>
                        <Search className="mr-2 h-5 w-5" />
                        Retry Failed Search (Free)
                      </>
                    )}
                  </Button>
                )}
              </CardContent>
            </Card>
            {/* Privacy Notice */}
            <div className="text-center text-sm text-gray-500 space-y-2">
              <p className="font-semibold">🔒 Your Privacy is Protected</p>
              <p>No personal information is stored. All data is deleted after download.</p>
            </div>
              </div>

              {/* Order Summary Sidebar */}
              <div className="lg:col-span-1">
                <OrderSummary
                  selectedTier={selectedTier}
                  tierPrice={tierPrices[selectedTier]}
                  companySearch={companySearch}
                  companySearchPrice={companySearchPrice}
                />
              </div>
            </div>
          </div>
        )}

        {searchMutation.isPending && (
          <LoadingSpinner message="Searching for jobs and analyzing matches..." />
        )}

        {step === 'results' && !searchMutation.isPending && (
          <div className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-bold" style={{ color: '#0066CC' }}>
                    Your Matched Jobs
                  </h2>
                  <p className="text-gray-600 mt-1">
                    Found {jobs.length} relevant jobs (from {totalFound} total searched)
                  </p>
                </div>
                <Button onClick={() => setStep('search')} variant="outline">
                  New Search
                </Button>
              </div>
              
              {/* Customer ID Display */}
              <Card className="bg-blue-50 border-blue-200">
                <CardContent className="pt-4 pb-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-semibold text-gray-700">Your Customer ID:</p>
                      <p className="text-2xl font-bold" style={{ color: '#0066CC' }}>
                        {customerId}
                      </p>
                      <p className="text-xs text-gray-600 mt-1">
                        Save this for your records. Include it if you need support.
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        navigator.clipboard.writeText(customerId);
                        toast.success('Customer ID copied!');
                      }}
                    >
                      Copy ID
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <p className="text-sm text-gray-700">
                  <strong>Next step:</strong> Select the jobs you want to apply for, then click "Generate Cover Letters" below.
                </p>
                <div className="flex gap-2">
                  <Button
                    onClick={handleSelectAll}
                    variant="outline"
                    size="sm"
                    className="text-xs"
                  >
                    Select All
                  </Button>
                  <Button
                    onClick={handleDeselectAll}
                    variant="outline"
                    size="sm"
                    className="text-xs"
                  >
                    Deselect All
                  </Button>
                </div>
              </div>
            </div>

            <div className="grid gap-4">
              {jobs.map((job) => (
                <Card key={job.jobId} className="hover:shadow-lg transition-shadow border-2 hover:border-blue-200">
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-4">
                      <Checkbox
                        checked={selectedJobs.has(job.jobId)}
                        onCheckedChange={() => toggleJobSelection(job.jobId)}
                        className="mt-1"
                      />
                      <div className="flex-1 space-y-3">
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <h3 className="font-bold text-lg" style={{ color: '#0066CC' }}>
                              {job.title}
                            </h3>
                            <p className="text-gray-700 font-medium">{job.company}</p>
                          </div>
                          <Badge 
                            variant={job.workStyle === 'Remote' ? 'default' : 'secondary'}
                            className={job.workStyle === 'Remote' ? 'bg-green-100 text-green-700' : ''}
                          >
                            {job.workStyle}
                          </Badge>
                        </div>
                        
                        <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                          <div className="flex items-center gap-1">
                            <MapPin className="h-4 w-4" />
                            {job.location}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {job.postingDate}
                          </div>
                          {job.jobUrl !== 'N/A' && (
                            <a
                              href={job.jobUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-1 hover:underline"
                              style={{ color: '#0066CC' }}
                            >
                              <ExternalLink className="h-4 w-4" />
                              View Job Posting
                            </a>
                          )}
                        </div>
                        
                        <div>
                          <p className="text-sm font-semibold text-gray-700 mb-2">
                            Matched Keywords ({job.matchCount}):
                          </p>
                          <div className="flex flex-wrap gap-2">
                            {job.keywordMatches.map((kw) => (
                              <Badge key={kw} variant="secondary" className="bg-blue-100 text-blue-700">
                                {kw}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="flex justify-between items-center pt-6 border-t">
              <p className="text-gray-600">
                <strong>{selectedJobs.size}</strong> job{selectedJobs.size !== 1 ? 's' : ''} selected
              </p>
              <Button
                onClick={handleGenerateCoverLetters}
                disabled={selectedJobs.size === 0}
                size="lg"
                className="text-lg px-8"
                style={{ backgroundColor: '#00CC66', color: 'white' }}
              >
                <FileText className="mr-2 h-5 w-5" />
                Generate Cover Letters ({selectedJobs.size})
              </Button>
            </div>
          </div>
        )}

        {step === 'generate' && (
          <div className="max-w-2xl mx-auto text-center space-y-8 py-16">
            <LoadingSpinner message={`Generating ${selectedJobs.size} personalized cover letter${selectedJobs.size !== 1 ? 's' : ''} using AI...`} />
            <p className="text-gray-500 mt-4">
              This usually takes 30-60 seconds
            </p>
          </div>
        )}

        {step === 'download' && (
          <div className="max-w-3xl mx-auto space-y-8">
            <div className="text-center space-y-4 py-8">
              <div className="mx-auto w-20 h-20 rounded-full flex items-center justify-center" style={{ backgroundColor: '#00CC66' }}>
                <CheckCircle2 className="h-12 w-12 text-white" />
              </div>
              <h2 className="text-4xl font-bold" style={{ color: '#0066CC' }}>
                Your Materials Are Ready!
              </h2>
              <p className="text-xl text-gray-600">
                Download your customized cover letters and job report below
              </p>
              
              {/* Customer ID Display */}
              <Card className="bg-blue-50 border-blue-200 max-w-md mx-auto">
                <CardContent className="pt-4 pb-4">
                  <p className="text-sm font-semibold text-gray-700 mb-2">Your Customer ID:</p>
                  <div className="flex items-center justify-center gap-3">
                    <p className="text-2xl font-bold" style={{ color: '#0066CC' }}>
                      {customerId}
                    </p>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        navigator.clipboard.writeText(customerId);
                        toast.success('Customer ID copied!');
                      }}
                    >
                      Copy
                    </Button>
                  </div>
                  <p className="text-xs text-gray-600 mt-2">
                    Email principal@jobsearchassist.com if you need support
                  </p>
                </CardContent>
              </Card>
            </div>

            <Card className="shadow-lg">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-white">
                <CardTitle style={{ color: '#0066CC' }}>Download Your Files</CardTitle>
                <CardDescription>
                  Click any file to download. Files will be deleted in 1 hour for your privacy.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3 pt-6">
                {downloadFiles.map((file) => (
                  <a
                    key={file.name}
                    href={file.url}
                    download={file.name}
                    className="flex items-center justify-between p-4 border-2 rounded-lg hover:bg-blue-50 hover:border-blue-300 transition-all group"
                  >
                    <div className="flex items-center gap-3">
                      <FileText className="h-6 w-6 text-gray-400 group-hover:text-blue-600" />
                      <span className="font-medium text-gray-700 group-hover:text-blue-700">
                        {file.name}
                      </span>
                    </div>
                    <Download className="h-5 w-5 text-gray-400 group-hover:text-blue-600" />
                  </a>
                ))}
              </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 gap-4">
              <Button 
                onClick={() => {
                  setStep('search');
                  setSelectedJobs(new Set());
                  setJobs([]);
                  setResumeFile(null);
                }} 
                variant="outline"
                size="lg"
                className="w-full"
              >
                Start New Search
              </Button>
              <Button 
                onClick={() => setStep('results')} 
                size="lg"
                className="w-full"
                style={{ backgroundColor: '#0066CC', color: 'white' }}
              >
                Back to Results
              </Button>
            </div>

            <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
              <p className="text-sm text-gray-700">
                <strong>🎉 Success!</strong> You've just saved hours of work. Good luck with your applications!
              </p>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t mt-20 bg-gray-50">
        <div className="container py-8">
          <div className="text-center space-y-2">
            <p className="text-sm text-gray-600">
              © 2025 JobSearchAssist.org - Helping you play the numbers game
            </p>
            <p className="text-xs text-gray-500">
              Privacy-first job search. No data stored permanently.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

