import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Check } from "lucide-react";

interface PricingTierCardProps {
  tier: 'expert' | 'pro' | 'superhero';
  price: number;
  selected: boolean;
  onSelect: () => void;
}

const tierDetails = {
  expert: {
    name: 'Expert',
    description: 'Perfect for focused job searches',
    features: [
      'Up to 30 job results',
      '3 AI-generated keywords',
      'Basic resume check',
      'Google Jobs search',
    ],
    popular: false,
  },
  pro: {
    name: 'Pro',
    description: 'Most popular for serious job seekers',
    features: [
      'Up to 60 job results',
      '5 AI-generated keywords',
      'Enhanced resume check',
      'Google Jobs search',
    ],
    popular: true,
  },
  superhero: {
    name: 'Superhero',
    description: 'Maximum coverage for your job search',
    features: [
      'Up to 100 job results',
      '7 AI-generated keywords',
      'Premium resume check',
      'Google Jobs search',
    ],
    popular: false,
  },
};

export default function PricingTierCard({ tier, price, selected, onSelect }: PricingTierCardProps) {
  const details = tierDetails[tier];
  
  return (
    <Card
      className={`cursor-pointer transition-all ${
        selected
          ? 'border-blue-600 border-2 shadow-lg bg-blue-50'
          : 'border-gray-200 hover:border-blue-300 hover:shadow-md'
      } ${details.popular ? 'relative' : ''}`}
      onClick={onSelect}
    >
      {details.popular && (
        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
          <span className="bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-full">
            MOST POPULAR
          </span>
        </div>
      )}
      <CardHeader className="text-center pb-4">
        <CardTitle className="text-2xl font-bold" style={{ color: '#0066CC' }}>
          {details.name}
        </CardTitle>
        <CardDescription className="text-sm">{details.description}</CardDescription>
        <div className="mt-4">
          <span className="text-4xl font-bold" style={{ color: '#0066CC' }}>
            ${price}
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <ul className="space-y-3">
          {details.features.map((feature, index) => (
            <li key={index} className="flex items-start gap-2">
              <Check className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
              <span className="text-sm text-gray-700">{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}

