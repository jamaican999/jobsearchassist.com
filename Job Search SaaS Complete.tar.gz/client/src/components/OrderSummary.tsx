import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface OrderSummaryProps {
  selectedTier: 'expert' | 'pro' | 'superhero';
  tierPrice: number;
  companySearch: boolean;
  companySearchPrice: number;
}

const tierNames = {
  expert: 'Expert Tier',
  pro: 'Pro Tier',
  superhero: 'Superhero Tier',
};

export default function OrderSummary({
  selectedTier,
  tierPrice,
  companySearch,
  companySearchPrice,
}: OrderSummaryProps) {
  const total = tierPrice + (companySearch ? companySearchPrice : 0);
  
  return (
    <Card className="sticky top-24 shadow-lg border-2 border-blue-200">
      <CardHeader className="bg-blue-50">
        <CardTitle className="text-lg" style={{ color: '#0066CC' }}>
          Order Summary
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4 pt-6">
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-gray-700">
              {tierNames[selectedTier]}
            </span>
            <span className="text-sm font-semibold" style={{ color: '#0066CC' }}>
              ${tierPrice.toFixed(2)}
            </span>
          </div>
          
          {companySearch && (
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-gray-700">
                Company Search
              </span>
              <span className="text-sm font-semibold" style={{ color: '#0066CC' }}>
                ${companySearchPrice.toFixed(2)}
              </span>
            </div>
          )}
        </div>
        
        <div className="border-t pt-4">
          <div className="flex justify-between items-center">
            <span className="text-base font-bold text-gray-900">Total</span>
            <span className="text-2xl font-bold" style={{ color: '#0066CC' }}>
              ${total.toFixed(2)}
            </span>
          </div>
        </div>
        
        <div className="bg-green-50 border border-green-200 rounded-lg p-3 mt-4">
          <p className="text-xs text-green-800 text-center">
            ✓ Secure payment via Stripe
          </p>
          <p className="text-xs text-green-800 text-center mt-1">
            ✓ Results delivered instantly
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

