# Deployment Guide - JobSearchAssist.org

This guide covers deploying the JobSearchAssist.org application to production.

## 🎯 Pre-Deployment Checklist

- [ ] All environment variables configured for production
- [ ] Database created and accessible
- [ ] Stripe account in live mode with API keys
- [ ] Domain name configured and DNS pointing to server
- [ ] SSL certificate obtained (Let's Encrypt recommended)
- [ ] Backup strategy in place for database

## 🔧 Environment Variables

### Required Production Variables

```env
# Database - Use production database URL
DATABASE_URL=mysql://user:password@production-host:port/database

# Authentication - Keep secure
JWT_SECRET=<generate-strong-random-secret>
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im
OWNER_OPEN_ID=<your-manus-open-id>
OWNER_NAME=<your-name>

# Stripe - Use LIVE keys (not test keys)
STRIPE_SECRET_KEY=sk_live_...
STRIPE_PUBLISHABLE_KEY=pk_live_...

# Application - Use production domain
VITE_APP_ID=<your-production-app-id>
VITE_APP_TITLE=JobSearchAssist.org
VITE_APP_LOGO=/logo.svg
VITE_APP_URL=https://jobsearchassist.org

# Manus Built-in APIs
BUILT_IN_FORGE_API_URL=https://forge.manus.im
BUILT_IN_FORGE_API_KEY=<your-production-forge-key>

# Search APIs - Use production keys
SERPAPI_API_KEY=<your-serpapi-production-key>
SERPER_API_KEY=<your-serper-production-key>

# Analytics (optional)
VITE_ANALYTICS_ENDPOINT=<your-analytics-endpoint>
VITE_ANALYTICS_WEBSITE_ID=<your-website-id>
```

## 🚀 Deployment Options

### Option 1: Traditional VPS (DigitalOcean, Linode, AWS EC2)

#### 1. Server Setup

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 22
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install pnpm
npm install -g pnpm

# Install PM2 for process management
npm install -g pm2
```

#### 2. Deploy Application

```bash
# Clone repository
git clone <your-repo-url> /var/www/job-search-saas
cd /var/www/job-search-saas

# Install dependencies
pnpm install

# Create .env file with production variables
nano .env

# Push database schema
pnpm db:push

# Build application
pnpm build

# Start with PM2
pm2 start npm --name "job-search-saas" -- start
pm2 save
pm2 startup
```

#### 3. Configure Nginx

```nginx
server {
    listen 80;
    server_name jobsearchassist.org www.jobsearchassist.org;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

#### 4. SSL with Let's Encrypt

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d jobsearchassist.org -d www.jobsearchassist.org
```

### Option 2: Docker Deployment

#### 1. Create Dockerfile

```dockerfile
FROM node:22-alpine

WORKDIR /app

# Install pnpm
RUN npm install -g pnpm

# Copy package files
COPY package.json pnpm-lock.yaml ./

# Install dependencies
RUN pnpm install --frozen-lockfile

# Copy source code
COPY . .

# Build application
RUN pnpm build

# Expose port
EXPOSE 3000

# Start application
CMD ["pnpm", "start"]
```

#### 2. Create docker-compose.yml

```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
    env_file:
      - .env
    restart: unless-stopped
    depends_on:
      - db

  db:
    image: mysql:8.0
    environment:
      MYSQL_ROOT_PASSWORD: ${DB_ROOT_PASSWORD}
      MYSQL_DATABASE: jobsearch
      MYSQL_USER: ${DB_USER}
      MYSQL_PASSWORD: ${DB_PASSWORD}
    volumes:
      - db_data:/var/lib/mysql
    restart: unless-stopped

volumes:
  db_data:
```

#### 3. Deploy with Docker

```bash
docker-compose up -d
```

### Option 3: Platform as a Service (Heroku, Railway, Render)

#### Heroku

```bash
# Install Heroku CLI
# Login to Heroku
heroku login

# Create app
heroku create jobsearchassist

# Add database
heroku addons:create jawsdb:kitefin

# Set environment variables
heroku config:set JWT_SECRET=<your-secret>
heroku config:set STRIPE_SECRET_KEY=<your-key>
# ... set all other variables

# Deploy
git push heroku main

# Run database migration
heroku run pnpm db:push
```

## 🔄 Continuous Deployment

### GitHub Actions Workflow

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Production

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '22'
    
    - name: Install pnpm
      run: npm install -g pnpm
    
    - name: Install dependencies
      run: pnpm install
    
    - name: Build
      run: pnpm build
    
    - name: Deploy to server
      uses: appleboy/ssh-action@master
      with:
        host: ${{ secrets.SERVER_HOST }}
        username: ${{ secrets.SERVER_USER }}
        key: ${{ secrets.SSH_PRIVATE_KEY }}
        script: |
          cd /var/www/job-search-saas
          git pull
          pnpm install
          pnpm build
          pm2 restart job-search-saas
```

## 📊 Monitoring

### PM2 Monitoring

```bash
# View logs
pm2 logs job-search-saas

# Monitor resources
pm2 monit

# View status
pm2 status
```

### Health Checks

Set up health check endpoint monitoring:
- Use UptimeRobot or similar service
- Monitor `https://jobsearchassist.org/health`
- Set up alerts for downtime

## 🔐 Security Best Practices

1. **Environment Variables**
   - Never commit `.env` to git
   - Use secrets management (AWS Secrets Manager, HashiCorp Vault)
   - Rotate keys regularly

2. **Database**
   - Use strong passwords
   - Enable SSL connections
   - Regular backups
   - Restrict access by IP

3. **Application**
   - Keep dependencies updated
   - Enable rate limiting
   - Use HTTPS only
   - Set secure headers

4. **Stripe**
   - Use webhook signatures
   - Validate all payment data
   - Test refund flows
   - Monitor for fraud

## 🔄 Updates and Maintenance

### Regular Updates

```bash
# Pull latest code
git pull

# Update dependencies
pnpm update

# Rebuild
pnpm build

# Restart
pm2 restart job-search-saas
```

### Database Migrations

```bash
# After schema changes
pnpm db:push

# Or use migration files
pnpm drizzle-kit generate:mysql
pnpm drizzle-kit migrate
```

## 🆘 Troubleshooting

### Application won't start
- Check environment variables
- Verify database connection
- Check logs: `pm2 logs`
- Verify port 3000 is available

### Payment failures
- Verify Stripe keys are live mode
- Check webhook configuration
- Review Stripe dashboard for errors

### Database connection issues
- Verify DATABASE_URL format
- Check firewall rules
- Ensure database server is running
- Test connection with MySQL client

## 📞 Support

For deployment issues:
- Check logs first
- Review this guide
- Contact support at [your-email]

---

**Last Updated**: [Current Date]

