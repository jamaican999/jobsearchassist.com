# Job Search SaaS - TODO

## Bugs
- [x] Fix PDF parser import error (pdf-parse dependency)
- [x] Fix GeoIP lookup import error (geoip-lite dependency)
- [x] Test complete job search workflow end-to-end - Successfully found 10 jobs with working URLs

## Completed Features
- [x] Basic job search functionality
- [x] Resume upload (PDF)
- [x] Cover letter generation
- [x] Customer ID tracking (JSA-2025-XXXXXX)
- [x] Automated refund system
- [x] Batch 2 optional search
- [x] Admin dashboard at /admin
- [x] Analytics tracking
- [x] Deployment to Manus

## Future Enhancements (Post Go-Live)
- [ ] Add "Select All" button for job selection (or numbered list with option to enter "all" or specific numbers)
- [ ] Stripe payment integration
- [ ] Email notifications for refunds
- [ ] Password protection for admin dashboard



## In Progress

## Recently Completed
- [x] Create marketing landing page at root (/) with content from marketing site screenshots
  - Hero section: "Let JobSearchAssist.org help you play the numbers game"
  - About section with privacy network graphic
  - Value proposition: "3 out of 100 applications get responses" stat
  - Features: No endless scrolling, customized cover letters, personalized pitches
  - Services section: "Tailored Support for Job Seekers"
  - CTA button: "Let's Get Started!" → links to /app
  - Footer with contact email
  - Move current job search form to /app route
  - Marketing assets saved in /marketing-assets/ folder



## In Progress

## Recently Completed
- [x] Add FAQ section to landing page with 10 questions and answers



## In Progress

## Recently Completed
- [x] Create comprehensive observability table for transaction tracking with columns: transaction_id, customer_id, timestamp, search_keywords, required_skills, min_matches, total_jobs_found, jobs_matched, jobs_selected, cover_letters_generated, user_ip, user_location, user_agent, status, error_message, refund_flagged, processing_time_ms



## In Progress

## Recently Completed
- [x] Update landing page hero header to sentence case with URL in lowercase italic and slightly different styling



## In Progress
- [ ] Add US Government labor statistics links distributed throughout the site

## Recently Completed
- [x] Three UI improvements for better user experience
  - Added "Select All" and "Deselect All" buttons on job results page
  - Added "How It Works" instructions section with 5-step guide on search page
  - Made checkbox borders darker (border-2 border-gray-400) for better visibility
- [x] Stripe payment integration - Pay First model with $25 early adopter pricing
  - Installed Stripe packages (@stripe/stripe-js, stripe)
  - Created Stripe service with checkout session and refund functions
  - Added payment endpoints to backend (createCheckoutSession, verifyPayment)
  - Updated frontend to redirect to Stripe Checkout before job search
  - Changed button text to "Search Jobs - $25"
  - Implemented payment success/cancel handling
  - Search runs automatically after successful payment



## Current Session
- [x] Add Google Tag (gtag.js) tracking code for Google Ads conversion tracking (AW-17684326360)


- [x] Remove problematic legal waiver FAQ question from landing page



## Multi-Tier Pricing Implementation
- [ ] Create pricing tier cards UI (Expert $10, Pro $25, Superhero $40-50)
- [ ] Add company-specific search checkbox (+$2.50 add-on)
- [ ] Build dynamic order summary sidebar with real-time price updates
- [ ] Integrate Serper.dev API (replace SerpAPI)
- [ ] Request SERPER_API_KEY secret from user
- [ ] Update backend to handle tier-based result limits (30/60/100 jobs)
- [ ] Update Stripe checkout to accept dynamic pricing based on tier + add-ons
- [ ] Implement company-specific search logic
- [ ] Add AI keyword generation (3/5/7 keywords based on tier)
- [ ] Add resume check features (basic/enhanced/premium based on tier)
- [ ] Test complete flow: tier selection → form → payment → results
- [ ] Update landing page to show pricing information


- [x] Add admin bypass button to skip payment for testing (admin-only)
- [x] Update frontend handleSearch to send tier and companySearch parameters
- [x] Create Serper.dev service for job search API
- [x] Update Stripe checkout to accept dynamic pricing based on tier
- [x] Add pricing tier selection UI (Expert/Pro/Superhero cards)
- [x] Add company search add-on option (+$2.50)
- [x] Create dynamic order summary sidebar
- [x] Integrate Serper.dev API key into environment



## Serper.dev Backend Integration
- [x] Update job search router to accept tier and company search parameters
- [x] Modify jobSearchService to use Serper.dev instead of SerpAPI
- [x] Implement tier-based result limits (Expert: 30, Pro: 60, Superhero: 100)
- [x] Remove SerpAPI dependency and import
- [x] Update frontend admin bypass to send tier and company parameters



## Production Deployment Fix
- [x] Fix OpenAI initialization to use lazy loading instead of module-level initialization
- [x] Implement dynamic import for OpenAI to defer library loading until runtime
- [ ] Test production deployment after dynamic import fix



## Loading Animation
- [x] Create loading spinner component
- [x] Show loading animation during job search
- [x] Show loading animation during cover letter generation
- [x] Test loading states



## Stripe Dynamic Import Fix
- [x] Implement dynamic import for Stripe library (same as OpenAI fix)
- [ ] Test production deployment after Stripe fix



## Landing Page Updates for Google Ads Sitelinks
- [x] Fix grammar: remove period before "—— a game-changer"
- [x] Update "50-100" to "30-100 (depending on the plan selected)"
- [x] Add "How It Works" section with id="how-it-works"
- [x] Add "Pricing" section with id="pricing" showing three tiers
- [x] Add "Statistics" section with id="statistics" containing US DOL links
- [x] Add id="faq" to FAQ section
- [x] Test anchor links work correctly



## Cancel and Retry Button Implementation
- [x] Update database schema to track retry attempts and payment intent
- [x] Add retryCount, paymentIntentId, searchExpiresAt, sessionId to search_analytics table
- [x] Implement automatic Stripe refund on search failure
- [x] Add Cancel button to job search form (visible after CTA clicked, before payment)
- [x] Add Retry button (visible only for failed searches within 30 min OR same session)
- [x] Implement retry validation logic (same session OR 30 min window)
- [x] Track retry attempts (max 2 failures before permanent refund status)
- [x] Test automatic refund triggers on search failure
- [x] Test retry button functionality with session and time constraints
- [x] Test Cancel button resets form state properly




## Stripe Payment Error Fix and Pricing Redesign
- [ ] Investigate Stripe checkout page not fully rendering issue
- [ ] Fix Stripe redirect or URL configuration
- [ ] Add better loading state during Stripe redirect
- [x] Create condensed pricing section format (compact display)
- [x] Move pricing section above CTA button for better visibility
- [x] Test complete payment flow from form to Stripe and back
- [x] Verify payment success redirects work correctly




## User Testimonial Section
- [x] Create testimonial component with three example reviews
- [x] Position testimonials near pricing section for trust-building
- [x] Include user names, roles, and star ratings
- [x] Design with professional styling matching site theme




## Landing Page Pricing Section Reorder
- [x] Move pricing section ABOVE the "Get Started" CTA button on landing page
- [x] Ensure pricing is visible before user clicks CTA


